# 李坤的个人网站

这是网站的完整源码、可编辑内容和公开素材。复制本目录，或下载公开仓库里的源码压缩包并解压，就能在另一台电脑继续更新。它是静态网站，通过修改内容文件更新，没有网页管理后台。

本目录包含首页小程序码与首屏打开入口、独立辅修与能力认证区、四个项目的详细章节和流程、小程序项目荣誉、逐项软件著作权状态及细腻动效。实际验证结果与发布版本记录在 `tests/TEST-REPORT.md` 中。

## 在电脑上打开

安装 [Node.js 24 LTS](https://nodejs.org/)（或 22.22.0 及以上），在本目录打开终端，首次运行：

```bash
npm ci
npm run dev
```

打开终端显示的本地地址。以后启动只需 `npm run dev`。关闭预览在终端按 `Ctrl+C`。

## 改介绍、经历和动态

- `src/content/profile.json`：自我介绍、能力、经历、项目和荣誉。
- `src/content/notes/`：成长记录，每篇一个 Markdown 文件；复制已有文件，填写日期、标题和正文。
- `public/`：网站使用的公开图片和二维码。新增素材时保留现有文件的命名方式，并在对应内容文件里引用。
- `DESIGN.md`：2026-11-02 按用户要求恢复的原设计约定（基线 `40787e9`）。
- `src/styles/global.css`：基础布局、配色和现有组件样式。
- `src/styles/enhancements.css`：首页小程序入口、荣誉重点、项目章节与流程、科研凭证，以及装饰和滚动入场动效。
- `src/` 中的页面和交互脚本：调整布局与行为；日常更新文字通常不用改它们。

修改 JSON 时注意引号和逗号，先预览页面再发布。请核实新荣誉与经历，不把原始简历、材料表格或带隐私的证书直接放进 `public/`。

目前展示 16 项荣誉：国家级 5 项、省级 10 项、贵客松特殊奖 1 项。中国国际大学生创新大赛省级金奖 1 项、银奖 2 项优先展示。证书字段使用真实公开图片的相对路径；没有图片时保留 `null`，页面不生成查看按钮。未知日期保留空值，不为排版补造日期。

首页按“关于我 → 小程序体验 → 荣誉与成长 → 辅修与能力认证 → 作品 → 经历”的顺序展示，自我介绍是主视觉之后的第一正文区。荣誉重点保留创新大赛、挑战杯两张优先卡，另有三张国家级卡。`nationalHonorHighlights` 的 `id / title / eyebrow / description` 控制国家级卡文案；`awardIds` 引用既有国家级荣誉，奖级和项数自动按实际引用汇总，不能把卡片再次计入荣誉总数。`certificateLabels` 与 `awardIds` 同序，为对应证书按钮提供短名称；证书文件仍从 `awards` 读取。更换引用时一起核对，避免证书错配。

科研部分分别记录论文、专利申请和软件著作权：论文介绍已发表成果；4 项专利为申请受理；软件著作权为 1 项已登记、另 2 项申请受理。更新时保持已发表、已受理、已登记和已授权的状态区别，避免重复计数。

`research` 的 `kind` 区分 `paper`、`patent`、`software`。软件成果各占一张卡：苗医数字馆已登记，初中物理智能助学平台与苗遗智卫智慧健康软件为申请受理。`status` 决定汇总显示；只有真实对应的公开证书才填写 `certificate`，受理项不能借用登记证书。

## 更新辅修与能力认证

首页“学习”导航指向 `#learning`，内容来自 `profile.json` 的 `learning`：

- `program`：实验班、辅修方向、介绍与 `topics[{title,text}]`，目前为华为创新实验班的 AI 视觉识别课程。
- `certification`：HCIP 名称、说明与当前 `status`，目前备考中。实际通过后再更新，不提前写已取得认证。
- `language`：CET-6 名称、通过状态与时间；不展示原成绩单身份编号。

不推断具体 HCIP 方向、辅修结课日期或另授学位。课程主题和认证计划可以按实际进度继续更新。

## 更新联系方式

`profile.json`的`contact.phone / contact.qq`保存本人确认公开的电话和QQ；填写字符串，页面展示号码并提供复制按钮，电话使用`tel:`链接。暂不展示的渠道留空；邮箱、微信仍未确认，不推断添加。桌面和手机导航的“联系”指向`#contact`。

复制成功由浏览器Clipboard API返回后反馈；失败时提示长按或选中号码手动复制，号码文字保持可选择。QQ只复制号码，不自动添加好友或发送消息。网站与当前源码仓库公开，因此填写这里的联系方式属于本人公开展示信息。

## 更新项目章节与流程

`profile.json` 的每个 `projects` 元素可填写以下字段：

| 字段 | 结构与用途 |
| --- | --- |
| `storySections` | `[{ id, kicker, title, paragraphs }]`，详细章节；`paragraphs` 是字符串数组，每项呈现为一个段落 |
| `workflow` | `[{ title, text }]`，有顺序的操作或体验步骤；数组顺序就是页面顺序 |
| `features` | 原有关键能力列表，保留给简洁的功能说明 |
| `qr` | 小程序码的 `image`、`squareImage`、`label`、`instructions`；仅有真实二维码的项目填写 |
| `awardIds` | 引用全站已有荣誉的 ID，用于项目荣誉与首页小程序荣誉摘要，不增加全站获奖计数 |
| `honorIntro` | 项目荣誉介绍，说明历史参赛名与当前作品的关系 |

当前四个项目各有 4 个详细章节。灵岐智和精成分别有 5 个流程步骤，云上屯堡和智学理验分别有 4 个。页面先展示前两章，再展示流程和关键能力，最后展示剩余章节。章节 `id` 在项目内必须唯一、稳定；第一章的 `problem` 用于“问题与思路”目录锚点，不随标题修改。新增段落直接加入 `paragraphs`，不在字符串中写 HTML。

首页显眼的小程序卡和首屏打开入口共同读取 `id: "lingqizhi"` 的 `qr`。方形 `squareImage` 用于首页显示、放大和保存；详情页保存 `image` 指向的完整横版原图。更换码时同步保留两种图片的对应关系，不能重绘码点或覆盖中心图。

灵岐智沿用早期“苗遗智卫”的项目荣誉：机器人及人工智能大赛国一/省一、RAICOM 国二/省一、计算机设计大赛苗医国三/省一。首页摘要和详情页 `#project-awards` 共同引用 `awardIds`；创新金银奖和挑战杯不据此关联。荣誉的 `projectId` 为首页提供作品链接，修改关联时同步维护。

## 维护动效

新增动效集中在 `src/styles/enhancements.css`，并由基础布局统一引入；修改前同时检查 `global.css`，避免同一属性反复覆盖。轨道描边、光晕呼吸、装饰图形与卡片反馈应保持轻量，二维码内容与正文保持稳定。

小精灵的 `.character-card` 是固定点击区域，倾斜在 `.sprite-visual`、浮动在 `.sprite-float`，单次打招呼只动画内部 `[data-sprite-art]`，每次原生点击取消旧动作并立即重新开始。装饰层不接收指针，图片禁拖拽；暂停动作时立即取消打招呼动画，文字反馈仍可用。调整大小时保留按钮安全边距，并复验头、身体、脚和连点，不能再让按钮本身随动画移动。

滚动入场状态由 `src/scripts/site.ts` 设置；未执行 JavaScript 时内容默认可见。调整 `[data-reveal-state]` 或增加持续动画时，同步维护 `html[data-motion=paused]` 和 `prefers-reduced-motion: reduce` 的回退。暂停或减少动态效果仍应保留必要的文字反馈、按钮和焦点；移动端和键盘操作都需要复验。

## 发布前检查

```bash
npm run check
npm run build
npm run preview
```

`build` 已包含 `node scripts/validate-public.mjs`。打开预览地址，在手机和电脑上检查导航、图片、项目目录与流程、科研和荣誉凭证弹窗、小程序码两处入口及下载、动效暂停和新增内容。检查脚本会拦截常见密钥、私有目录和原电脑路径；公开证书上的隐私仍需人工检查。

## GitHub Pages 发布

网站已部署到 [https://lik285154-web.github.io/](https://lik285154-web.github.io/)。发布仓库为 [lik285154-web.github.io](https://github.com/lik285154-web/lik285154-web.github.io)。

### 当前方案：浏览器上传源码压缩包，自动构建

仓库根目录保存 `website-source.zip` 和 `.github/workflows/deploy-pages.yml`。压缩包内顶层是 `site/`，包含源码、内容、公开素材和依赖锁文件；不包含依赖目录、构建成品、本地测试输出、Git 内部文件、私密配置和高分辨率证书 PNG。网站使用已脱敏的 WebP 证书图片。

1. 在本目录运行 `npm run check`、`npm run build`、`npm run package:source`。最新的 `website-source.zip` 会生成在本目录的上一级。
2. 打开 GitHub 仓库，点击 **Add file → Upload files**，上传或覆盖根目录的 `website-source.zip`。
3. 在 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
4. 当前仓库的自动发布工作流已配置，日常只需更新压缩包。若另建仓库，可复制当前仓库的 [.github/workflows/deploy-pages.yml](https://github.com/lik285154-web/lik285154-web.github.io/blob/main/.github/workflows/deploy-pages.yml)；压缩包方案与普通源码方案的工作流不能混用。
5. 在 **Actions** 等待构建和发布都成功，再打开网站链接并测试。需要重跑时，选择 **Publish personal website from source archive → Run workflow**。

工作流先解压源码，再安装锁定依赖、构建和检查，最后只把 `site/dist/` 发布到 Pages。源码压缩包在 GitHub 仓库中可下载恢复，私密配置不上传。**本地修改不会自动出现在网上**，更新后需重新打包并上传压缩包。

打包命令使用 Python 3 标准库；新电脑未安装 Python 时，可从 [python.org](https://www.python.org/downloads/) 安装。网站开发和浏览只需 Node.js。

### 后续方案：直接维护源码仓库

如果希望使用 Git 提交文字和图片后自动上线，可改为直接上传本 `site` 源码目录，以它作为仓库根，并使用本目录 `.github/workflows/deploy-pages.yml`。不要上传上一级“个人网站”或完整“介绍”文件夹，也不要沿用压缩包版本的根工作流。

1. 创建网站仓库，默认分支使用 `main`，上传本目录的源码、`package-lock.json` 和公开素材。
2. 在仓库 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
3. 推送 `main` 分支，或在 **Actions → Publish personal website → Run workflow** 手动发布。
4. 等 Actions 中构建与发布都成功后，打开 Pages 页面给出的地址。首次发布也应测试在线地址及手机访问。

已有仓库日常更新，在本目录运行：

```bash
git status
git add src/content public
git commit -m "更新个人介绍和成长记录"
git push origin main
```

如果同时修改了页面、样式或说明，检查 `git status` 后补充添加相关文件。构建和密钥不需要上传。更新后在 Actions 查看发布状态，不要把本地预览地址发送给访问者。

普通项目仓库的链接为 `https://用户名.github.io/仓库名/`；仓库名为 `用户名.github.io` 时，链接为 `https://用户名.github.io/`。工作流会自动设置对应的 `SITE_URL` 与 `PAGES_BASE`，并只发布 `dist/`。若以后绑定自定义域名，需同步调整工作流的地址配置。

## 换电脑继续

复制整个本目录即可；不必复制 `node_modules/` 和 `dist/`，在新电脑运行 `npm ci`。也可以在 GitHub 仓库下载 `website-source.zip`，解压后进入 `site`，再运行 `npm ci`。若后来改为直接维护源码仓库，可以克隆仓库继续，Git 提交记录保留历次修改。

上一级 `策划/` 保存材料核验和设计来源，不在公开网站仓库内。需要继续核实资料时，另行私下复制完整“个人网站”文件夹。网站启动、内容维护和发布均不需要图像 API。当前吉祥物是原创 AI 小精灵，保存在 `public/media/likun-ai-sprite.webp`；更换形象可通过已有 ChatGPT 生图后保存到 `public/media/`，再填写 `profile.json` 中的 `identity.avatar` 和 `avatarAlt`。本人照片独立展示，任何私密密钥均不随网站迁移。

## 交付记录

- 公开 URL：https://lik285154-web.github.io/ （2026-10-20 首次发布）。
- 测试记录：见 [tests/TEST-REPORT.md](./tests/TEST-REPORT.md)，按实际版本、日期记录桌面与手机结果；复现命令见 `tests/README.md`。
- 维护约定：见 `AGENTS.md`。
- 本地 Git 历史：复制文件夹时保留 `.git` 即可保留源码修改记录；当前在线仓库使用 ZIP 发布，日常按上面的压缩包流程更新。
- 字体许可：`public/licenses/` 中保存 DM Sans 与 Space Grotesk 的 SIL Open Font License。
