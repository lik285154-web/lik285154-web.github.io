# 李坤的个人网站

这是网站的完整源码、可编辑内容和公开素材。复制本目录，或下载公开仓库里的源码压缩包并解压，就能在另一台电脑继续更新。它是静态网站，通过修改内容文件更新，没有网页管理后台。

## 在电脑上打开

安装 [Node.js 24 LTS](https://nodejs.org/)（或 22.22.0 及以上），在本目录打开终端，首次运行：

```bash
npm ci
npm run dev
```

打开终端显示的本地地址。以后启动只需 `npm run dev`。关闭预览在终端按 `Ctrl+C`。

## 改介绍、经历和动态

- `src/content/profile.json`：自我介绍、能力、经历、项目和荣誉。
- `src/content/notes/`：成长记录，每篇一个 Markdown 文件；复制已有文件，填写日期、标题和正文。
- `public/`：网站使用的公开图片和二维码。新增素材时保留现有文件的命名方式，并在对应内容文件里引用。
- `src/` 中的页面和样式：调整布局、视觉和动效；日常更新文字通常不用改它们。

修改 JSON 时注意引号和逗号，先预览页面再发布。请核实新荣誉与经历，不把原始简历、材料表格或带隐私的证书直接放进 `public/`。

目前展示 16 项荣誉：国家级 5 项、省级 10 项、贵客松特殊奖 1 项。其中中国国际大学生创新大赛省级金奖 1 项、银奖 2 项由本人补充，证书待补；对应 `certificate` 和 `certificateDownload` 暂为 `null`，补齐实际证书后再填写图片路径。

## 发布前检查

```bash
npm run build
node scripts/validate-public.mjs
npm run preview
```

打开预览地址，在手机和电脑上检查导航、图片、项目与证书弹窗、小程序二维码和新增内容。检查脚本会拦截常见密钥、私有目录和原电脑路径；公开证书上的隐私仍需人工检查。

## GitHub Pages 发布

计划使用 `lik285154-web.github.io` 用户主页仓库，地址为 `https://lik285154-web.github.io/`。只有成功发布并测试这个地址后，才算上线。

### 当前方案：浏览器上传源码压缩包，自动构建

仓库根目录保存 `website-source.zip` 和 `.github/workflows/deploy-pages.yml`。压缩包内顶层是 `site/`，包含源码、内容、公开素材和依赖锁文件；不包含依赖目录、构建成品、本地测试输出、Git 内部文件、私密配置和高分辨率证书 PNG。网站使用已脱敏的 WebP 证书图片。

1. 先完成本地构建和公开素材检查，再准备最新的 `website-source.zip`。
2. 打开 GitHub 仓库，点击 **Add file → Upload files**，上传或覆盖根目录的 `website-source.zip`。
3. 在 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
4. 首次部署时，用网页 **Create new file** 创建根目录的 `.github/workflows/deploy-pages.yml`，完整粘贴上一级 `策划/github-pages-zip-workflow.yml` 的内容并提交。之后日常更新压缩包即可。
5. 在 **Actions** 等待构建和发布都成功，再打开网站链接并测试。需要重跑时，选择 **Publish personal website from source archive → Run workflow**。

工作流先解压源码，再安装锁定依赖、构建和检查，最后只把 `site/dist/` 发布到 Pages。源码压缩包在 GitHub 仓库中可下载恢复，私密配置不上传。**本地修改不会自动出现在网上**，更新后需重新打包并上传压缩包。

### 后续方案：直接维护源码仓库

如果希望使用 Git 提交文字和图片后自动上线，可改为直接上传本 `site` 源码目录，以它作为仓库根，并使用本目录 `.github/workflows/deploy-pages.yml`。不要上传上一级“个人网站”或完整“介绍”文件夹，也不要沿用压缩包版本的根工作流。

1. 创建网站仓库，默认分支使用 `main`，上传本目录的源码、`package-lock.json` 和公开素材。
2. 在仓库 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
3. 推送 `main` 分支，或在 **Actions → Publish personal website → Run workflow** 手动发布。
4. 等 Actions 中构建与发布都成功后，打开 Pages 页面给出的地址。首次发布也应测试在线地址及手机访问。

已有仓库日常更新，在本目录运行：

```bash
git status
git add src/content public
git commit -m "更新个人介绍和成长记录"
git push origin main
```

如果同时修改了页面、样式或说明，检查 `git status` 后补充添加相关文件。构建和密钥不需要上传。更新后在 Actions 查看发布状态，不要把本地预览地址发送给访问者。

普通项目仓库的链接为 `https://用户名.github.io/仓库名/`；仓库名为 `用户名.github.io` 时，链接为 `https://用户名.github.io/`。工作流会自动设置对应的 `SITE_URL` 与 `PAGES_BASE`，并只发布 `dist/`。若以后绑定自定义域名，需同步调整工作流的地址配置。

## 换电脑继续

复制整个本目录即可；不必复制 `node_modules/` 和 `dist/`，在新电脑运行 `npm ci`。也可以在 GitHub 仓库下载 `website-source.zip`，解压后进入 `site`，再运行 `npm ci`。若后来改为直接维护源码仓库，可以克隆仓库继续，Git 提交记录保留历次修改。

上一级 `策划/` 保存材料核验和设计来源，不在公开网站仓库内。需要继续核实资料时，另行私下复制完整“个人网站”文件夹。API 密钥不随网站迁移，在新电脑上按上一级 `工具/配置图像API.md` 重新配置。

## 交付记录

- 公开 URL：首次成功发布后填写实际地址。
- 测试记录：以实际测试报告为准，未执行的检查不视为通过。
- 维护约定：见 `AGENTS.md`。
