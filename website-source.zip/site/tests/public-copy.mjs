// Review only rendered copy and dialog metadata. Official image pixels and
// private source documents are outside this check.
const internalCopy = /本人补充|证书待补|待补证书|简历记载|(?:第一|第二|第三|第四|第五)署名(?:作者|人)|第二作者|作者排序|署名顺序|待核验|待核实|证据不足/;

export async function inspectPublicCopy(page) {
  const copy = await page.evaluate(() => ({
    body: document.querySelector('main')?.innerText || '',
    dialogs: Array.from(document.querySelectorAll('main [data-lightbox]'))
      .map(element => `${element.dataset.title || ''} ${element.dataset.caption || ''}`),
  }));
  const match = [copy.body, ...copy.dialogs].map(value => value.match(internalCopy)?.[0]).find(Boolean);
  if (match) throw new Error(`公开文案仍含内部审核措辞：${match}`);
  return '正文和所有图片弹窗说明无内部审核措辞';
}
