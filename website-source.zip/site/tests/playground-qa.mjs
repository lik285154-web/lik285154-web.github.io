import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
const require=createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
 try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('Install Playwright as described in tests/README.md');
const { chromium, webkit } = playwright;
const args = process.argv.slice(2);
const arg = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const out = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', arg('--label', 'playground-local'));
await fs.mkdir(out, { recursive: true });
const url = new URL(arg('--url', 'http://127.0.0.1:4322/')).href;
const scenarios = args.includes('--smoke') ? [[1440,1000,'mouse'],[390,844,'touch'],[360,780,'touch'],[390,844,'Space']] : [[1440,1000,'mouse'],[1024,900,'mouse'],[768,1024,'mouse'],[390,844,'touch'],[360,780,'touch'],[1920,1080,'mouse'],[844,390,'touch'],[1440,1000,'Enter'],[390,844,'Space']];
const groups=[],checks=[];
function check(name,pass,detail){checks.push({name,pass:Boolean(pass),detail});}
const save=()=>fs.writeFile(path.join(out,'geometry-results.json'),JSON.stringify({scope:'Basketball geometry on the supplied URL, actual native-input frames. Observational DOM instrumentation only; no animation seek or style/source injection. Audio is not asserted in this phase.',url,groups,checks},null,2)+'\n');
async function prepared(browser,width,height){
 const context=await browser.newContext({viewport:{width,height},deviceScaleFactor:1,hasTouch:width<900,reducedMotion:'no-preference',colorScheme:'light'});
 const page=await context.newPage(),errors=[],assetPromises=[];
 page.on('pageerror',error=>errors.push(String(error)));
 page.on('response',response=>{if(/\.(css|js|mjs)(?:\?|$)/.test(response.url())&&response.url().startsWith(url))assetPromises.push(response.body().then(body=>({url:response.url(),status:response.status(),bytes:body.length,sha256:crypto.createHash('sha256').update(body).digest('hex')})).catch(error=>({url:response.url(),error:String(error)})));});
 const response=await page.goto(url,{waitUntil:'networkidle'});
 await page.evaluate(()=>document.fonts.ready);
 await page.locator('[data-playground]').scrollIntoViewIfNeeded();
 await page.locator('[data-shot]').scrollIntoViewIfNeeded();
 await page.waitForTimeout(120);
 return{context,page,errors,status:response.status(),assets:()=>Promise.all(assetPromises)};
}
async function instrument(page,observeFor=2250){
 await page.evaluate(observeFor=>{
  const rect=element=>element.getBoundingClientRect().toJSON();
  const center=element=>{const b=element.getBoundingClientRect();return{x:b.x+b.width/2,y:b.y+b.height/2};};
  const width=element=>{const c=getComputedStyle(element),m=new DOMMatrix(c.transform==='none'?undefined:c.transform),s=c.scale==='none'?1:parseFloat(c.scale);return element.clientWidth*Math.hypot(m.a,m.b)*s;};
  const ball=document.querySelector('[data-shot]'),art=document.querySelector('[data-ball-art]'),rim=document.querySelector('.hoop-rim'),scene=document.querySelector('[data-playground]');
  const state=window.__geometry={clicks:[],frames:[],done:false,lastClickAt:null,before:{button:rect(ball),art:rect(art),artCenter:center(art),rim:rect(rim),rimCenter:center(rim),rimClearWidth:width(rim),scene:rect(scene),pointerEvents:getComputedStyle(ball).pointerEvents,sprite:rect(document.querySelector('[data-sprite-greet]'))}};
  const start=performance.now();
  ball.addEventListener('click',event=>{state.lastClickAt=performance.now();state.clicks.push({elapsed:state.lastClickAt-start,trusted:event.isTrusted,detail:event.detail,caption:document.querySelector('.shot-caption').textContent,flyingCount:document.querySelectorAll('.shot-ball').length});});
  const sample=now=>{
   const flying=document.querySelector('.shot-ball'),animation=flying?.getAnimations().find(a=>a.effect?.getTiming().duration===1450);
   const flyStyle=flying?getComputedStyle(flying):null;
   state.frames.push({elapsed:now-start,fly:flying?{center:center(flying),rect:rect(flying),clientWidth:flying.clientWidth,paintedDiameter:width(flying),transform:flyStyle.transform,independentScale:flyStyle.scale,animationTime:animation?.currentTime??null,progress:animation?animation.currentTime/1450:null}:null,button:rect(ball),rimCenter:center(rim),rimClearWidth:width(rim),rimTransform:getComputedStyle(rim).transform,scene:rect(scene),shooting:ball.classList.contains('shooting'),pointerEvents:getComputedStyle(ball).pointerEvents,sparkCount:document.querySelectorAll('.playground-spark').length,trailCount:document.querySelectorAll('.shot-trail').length,caption:document.querySelector('.shot-caption').textContent});
   if(state.lastClickAt===null || now-state.lastClickAt<observeFor)requestAnimationFrame(sample);else{state.done=true;state.after={button:rect(ball),sprite:rect(document.querySelector('[data-sprite-greet]')),flyingCount:document.querySelectorAll('.shot-ball').length,sparkCount:document.querySelectorAll('.playground-spark').length,trailCount:document.querySelectorAll('.shot-trail').length,caption:document.querySelector('.shot-caption').textContent};}
  };requestAnimationFrame(sample);
 },observeFor);
}
async function nativeShot(page,type,point){
 if(type==='touch')await page.touchscreen.tap(point.x,point.y);
 else if(type==='mouse')await page.mouse.click(point.x,point.y);
 else{await page.locator('[data-shot]').focus();await page.keyboard.press(type);}
}
function summarize(row){
 const obs=row.observation,frames=obs.frames.filter(f=>f.fly&&f.fly.progress!==null&&f.fly.progress>=0&&f.fly.progress<.8);
 const apex=frames.reduce((a,b)=>a.fly.center.y<b.fly.center.y?a:b),ai=frames.indexOf(apex);
 let cross=null;
 for(let i=Math.max(1,ai+1);i<frames.length;i++){
  const a=frames[i-1],b=frames[i],ay=a.fly.center.y-a.rimCenter.y,by=b.fly.center.y-b.rimCenter.y;
  if(ay<=0&&by>=0&&by>ay){const t=-ay/(by-ay),lerp=(x,y)=>x+(y-x)*t;cross={progress:lerp(a.fly.progress,b.fly.progress),dx:lerp(a.fly.center.x,b.fly.center.x)-lerp(a.rimCenter.x,b.rimCenter.x),diameter:lerp(a.fly.paintedDiameter,b.fly.paintedDiameter),rimClearWidth:lerp(a.rimClearWidth,b.rimClearWidth),bracketProgress:[a.fly.progress,b.fly.progress]};cross.fits=Math.abs(cross.dx)+cross.diameter/2<=cross.rimClearWidth/2;break;}
 }
 const deviations=obs.frames.map(f=>Math.max(...['x','y','width','height'].map(k=>Math.abs(f.button[k]-obs.before.button[k]))));
 const rimShift=obs.frames.map(f=>Math.hypot(f.rimCenter.x-obs.before.rimCenter.x,f.rimCenter.y-obs.before.rimCenter.y));
 const maxTopClip=Math.max(...frames.map(f=>Math.max(0,f.scene.y-(f.fly.center.y-f.fly.paintedDiameter/2))));
 const maxHorizontalClip=Math.max(...frames.map(f=>Math.max(0,f.scene.x-(f.fly.center.x-f.fly.paintedDiameter/2),f.fly.center.x+f.fly.paintedDiameter/2-f.scene.right)));
 row.summary={cross,apex:{progress:apex.fly.progress,center:apex.fly.center,diameter:apex.fly.paintedDiameter},maxTopClip,maxHorizontalClip,maxButtonDeviation:Math.max(...deviations),maxRimCenterShift:Math.max(...rimShift),frameCount:obs.frames.length,flyFrames:frames.length,clicks:obs.clicks,after:obs.after};
 const key=`${row.engine}-${row.width}x${row.height}-${row.input}`;
 check(key+' native trusted',obs.clicks.length===1&&obs.clicks[0].trusted,obs.clicks);
 check(key+' descending center fits',cross&&Math.abs(cross.dx)<1&&cross.fits,cross);
 check(key+' no top/horizontal crop',maxTopClip<=.1&&maxHorizontalClip<=.1,{maxTopClip,maxHorizontalClip});
 check(key+' fixed clickable button',row.summary.maxButtonDeviation<=.02&&obs.frames.every(f=>f.pointerEvents==='auto'),{deviation:row.summary.maxButtonDeviation,pointerEvents:[...new Set(obs.frames.map(f=>f.pointerEvents))]});
 check(key+' stable rim center',row.summary.maxRimCenterShift<=.1,row.summary.maxRimCenterShift);
 check(key+' finite cleanup',!obs.after.flyingCount&&!obs.after.sparkCount&&!obs.after.trailCount,obs.after);
 check(key+' no runtime errors',!row.errors.length,row.errors);
}
for(const engine of ['chromium','webkit']){
 const browser=await(engine==='chromium'?chromium:webkit).launch({headless:true,...(engine==='chromium' && process.platform==='darwin'?{executablePath:process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}:{})});
 try{
  for(const[width,height,input]of scenarios){
   const r=await prepared(browser,width,height);
   /** @type {Record<string, any>} */
   const row={engine,width,height,input,status:r.status,errors:r.errors,screenshots:[]};
   try{
    await instrument(r.page);
    const point=await r.page.locator('[data-shot]').evaluate(el=>{const b=el.getBoundingClientRect();return{x:b.x+b.width/2,y:b.y+b.height/2};});
    const rest=`${engine}-${width}x${height}-${input}-rest.png`;await r.page.screenshot({path:path.join(out,rest),animations:'allow'});row.screenshots.push(rest);
    await nativeShot(r.page,input,point);
    await r.page.waitForFunction(()=>window.__geometry.frames.some(f=>f.fly?.progress>=.48),null,{timeout:4000});
    const apex=`${engine}-${width}x${height}-${input}-near-apex.png`;row.apexBracketBefore=await r.page.evaluate(()=>window.__geometry.frames.at(-1));await r.page.screenshot({path:path.join(out,apex),animations:'allow'});row.apexBracketAfter=await r.page.evaluate(()=>window.__geometry.frames.at(-1));row.screenshots.push(apex);
    await r.page.waitForFunction(()=>window.__geometry.frames.some(f=>f.fly?.progress>=.68),null,{timeout:4000});
    const hit=`${engine}-${width}x${height}-${input}-near-hit.png`;row.hitBracketBefore=await r.page.evaluate(()=>window.__geometry.frames.at(-1));await r.page.screenshot({path:path.join(out,hit),animations:'allow'});row.hitBracketAfter=await r.page.evaluate(()=>window.__geometry.frames.at(-1));row.screenshots.push(hit);
    await r.page.waitForFunction(()=>window.__geometry.done,null,{timeout:4000});row.observation=await r.page.evaluate(()=>window.__geometry);summarize(row);
   }catch(error){row.error=String(error);row.observation=await r.page.evaluate(()=>window.__geometry).catch(()=>null);await r.page.screenshot({path:path.join(out,`${engine}-${width}x${height}-${input}-execution-error.png`)}).catch(()=>{});check(`${engine}-${width}x${height}-${input} execution`,false,row.error);}
   finally{row.assets=await r.assets();groups.push(row);await save();await r.context.close();}
   console.log(JSON.stringify({engine,width,height,input,error:row.error??null,summary:row.summary??null}));
  }
  for(const mode of ['repeat','resize']){
   const r=await prepared(browser,390,844);
   /** @type {Record<string, any>} */
   const row={engine,width:390,height:844,input:'touch',mode,errors:r.errors};
   try{
    await instrument(r.page,mode==='repeat'?3000:2250);const point=await r.page.locator('[data-shot]').evaluate(el=>{const b=el.getBoundingClientRect();return{x:b.x+b.width/2,y:b.y+b.height/2};});
    await nativeShot(r.page,'touch',point);await r.page.waitForTimeout(260);
    if(mode==='repeat'){await nativeShot(r.page,'touch',point);await r.page.waitForTimeout(260);await nativeShot(r.page,'touch',point);}
    else{await r.page.setViewportSize({width:844,height:390});await r.page.waitForTimeout(80);row.cancelled=await r.page.evaluate(()=>({fly:document.querySelectorAll('.shot-ball').length,spark:document.querySelectorAll('.playground-spark').length,trail:document.querySelectorAll('.shot-trail').length,shooting:document.querySelector('[data-shot]').classList.contains('shooting')}));check(engine+' resize cancels',!Object.values(row.cancelled).some(Boolean),row.cancelled);}
    await r.page.waitForFunction(()=>window.__geometry.done,null,{timeout:4500});row.observation=await r.page.evaluate(()=>window.__geometry);
    const o=row.observation,dev=Math.max(...o.frames.map(f=>Math.max(...['x','y','width','height'].map(k=>Math.abs(f.button[k]-o.before.button[k])))));
    if(mode==='repeat'){check(engine+' repeated native touch accepts all',o.clicks.length===3&&o.clicks.every(c=>c.trusted&&c.flyingCount===1),o.clicks);check(engine+' repeat fixed hitbox',dev<=.02,dev);check(engine+' repeat replaces and cleans',Math.max(...o.frames.map(f=>f.fly?1:0))===1&&!o.after.flyingCount&&!o.after.sparkCount&&!o.after.trailCount,o.after);}
    const name=`${engine}-${mode}-after.png`;await r.page.screenshot({path:path.join(out,name),animations:'allow'});row.screenshot=name;check(engine+' '+mode+' no runtime errors',!r.errors.length,r.errors);
   }catch(error){row.error=String(error);check(engine+' '+mode+' execution',false,row.error);}
   finally{row.assets=await r.assets();groups.push(row);await save();await r.context.close();}
   console.log(JSON.stringify({engine,mode,error:row.error??null,clicks:row.observation?.clicks,cancelled:row.cancelled,after:row.observation?.after}));
  }
 }finally{await browser.close();}
}
await save();console.log('GEOMETRY_COMPLETE '+JSON.stringify({groups:groups.length,checks:checks.length,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass)}));

if (checks.some(check => !check.pass)) process.exitCode = 1;
