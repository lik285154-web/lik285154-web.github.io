// User-visible reading-progress regression. Does not inspect implementation hooks.
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';
import config from './qa-config.mjs';

const require = createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
target.pathname = target.pathname.replace(/\/?$/, '/');
target.hash = '';
const siteDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const label = arg('--label', `reading-${new Date().toISOString().replace(/[:.]/g, '-')}`);
const output = path.resolve(siteDir, '.qa-output', label);
await fs.mkdir(output, { recursive: true });
if (await fs.access(path.join(output, 'reading-results.json')).then(() => true, () => false)) throw new Error('该标签已有结果，请使用新 --label 保留原证据');
const startedAt = new Date().toISOString();
const results = [], runtimeProblems = [];
const assert = (condition, message) => { if (!condition) throw new Error(message); };
const tolerance = 0.000002; // DOMMatrix serializes scale to about six decimal places.

async function state(page) {
  return page.evaluate(selectors => {
    const bar = document.querySelector('.reading-progress');
    if (!bar) throw new Error('阅读进度条不存在');
    const transform = getComputedStyle(bar).transform;
    const actual = transform === 'none' ? 1 : new DOMMatrixReadOnly(transform).a;
    const frozen = document.body.style.position === 'fixed';
    const logicalY = frozen ? -parseFloat(document.body.style.top || '0') : scrollY;
    const expected = frozen ? null : Math.max(0, Math.min(1, scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight)));
    return {
      timestamp: new Date().toISOString(), url: location.href,
      viewport: { width: innerWidth, height: innerHeight },
      scrollY, logicalY, scrollHeight: document.documentElement.scrollHeight,
      actualScale: actual, expectedScale: expected, transform,
      progressDifference: expected === null ? null : Math.abs(actual - expected),
      frozen, dialogOpen: document.querySelector('#image-dialog')?.open || false,
      activeFilter: document.activeElement?.dataset.awardFilter || null,
      activeFocusVisible: document.activeElement?.matches(':focus-visible') || false,
      focusTag: document.activeElement?.tagName,
      countText: document.querySelector('.filter-count')?.textContent || null,
      selected: [...document.querySelectorAll(selectors.awardFilters)].filter(e => e.getAttribute('aria-pressed') === 'true').map(e => e.dataset.awardFilter),
      renderedAwards: [...document.querySelectorAll(selectors.awardItems)].filter(e => {
        const s = getComputedStyle(e), r = e.getBoundingClientRect();
        return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
      }).length,
    };
  }, config);
}
async function settledProgress(page, trace, name) {
  await page.evaluate(() => document.fonts.ready);
  await page.waitForFunction(() => {
    const bar = document.querySelector('.reading-progress');
    if (!bar || document.body.style.position === 'fixed') return false;
    const value = getComputedStyle(bar).transform;
    const actual = value === 'none' ? 1 : new DOMMatrixReadOnly(value).a;
    const expected = Math.max(0, Math.min(1, scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight)));
    return Math.abs(actual - expected) <= 0.000002;
  }, undefined, { timeout: 3000 });
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const result = await state(page);
  trace.push({ name, ...result });
  assert(result.progressDifference <= tolerance, `${name}阅读进度与实际页面比例不符: ${JSON.stringify(result)}`);
  return result;
}
async function seek(page, selector, key, maximum = 90) {
  let presses = 0;
  while (!await page.evaluate(value => document.activeElement?.matches(value), selector) && presses < maximum) {
    await page.keyboard.press(key); presses++;
  }
  assert(await page.evaluate(value => document.activeElement?.matches(value), selector), `原生键盘未抵达${selector}`);
  return presses;
}
async function tap(page, selector) {
  const r = await page.locator(selector).boundingBox();
  const v = page.viewportSize();
  assert(r && r.y < v.height && r.y + r.height > 0 && r.x < v.width && r.x + r.width > 0, `无原生点击区域${selector}`);
  const x = (Math.max(0, r.x) + Math.min(v.width, r.x + r.width)) / 2;
  const y = (Math.max(0, r.y) + Math.min(v.height, r.y + r.height)) / 2;
  await page.touchscreen.tap(x, y);
}
async function wheelTo(page, selector, offset = 60) {
  for (let n = 0; n < 12; n++) {
    const delta = await page.locator(selector).evaluate((e, top) => e.getBoundingClientRect().top - top, offset);
    if (Math.abs(delta) <= 8) return;
    await page.mouse.wheel(0, delta);
    await page.waitForTimeout(120);
  }
  assert(Math.abs(await page.locator(selector).evaluate((e, top) => e.getBoundingClientRect().top - top, offset)) <= 12, `原生滚轮未抵达${selector}`);
}
async function screenshot(page, name) { await page.screenshot({ path: path.join(output, name + '.png') }); }
async function save() {
  await fs.writeFile(path.join(output, 'reading-results.json'), JSON.stringify({
    startedAt, finishedAt: new Date().toISOString(), url: target.href,
    scope: 'Eight workflows: two engines × phone/desktop homepage filters and resize, long project, long note. One QR modal per engine verifies frozen/restored reading proportion, not image-viewer geometry. Native keyboard/touch/wheel inputs; no DOM focus or scrolling injection. Counts are workflows, their assertions overlap.',
    limits: 'Simulated viewports, not physical-device rotation/swipe or screen readers. Chrome Tab; macOS WebKit Option+Tab (Alt+Tab). DOMMatrix rounding tolerance2e-6 only, not pixel/image tolerance. A fixed-background modal has no normal current-document denominator; its visible reading fraction is compared to the saved pre-open fraction.',
    tolerance, results, runtimeProblems,
    pass: results.length === 8 && results.every(r => r.pass) && runtimeProblems.length === 0,
  }, null, 2));
}

for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    const options = { headless: true };
    const macChrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
    if (engine === 'chromium') {
      if (process.env.QA_CHROME_PATH) options.executablePath = process.env.QA_CHROME_PATH;
      else if (process.platform === 'darwin' && await fs.access(macChrome).then(() => true, () => false)) options.executablePath = macChrome;
    }
    browser = await playwright[engine].launch(options);
  } catch (error) { results.push({ engine, test: '浏览器启动', pass: false, details: error.message }); await save(); continue; }
  async function check(name, viewport, mobile, action) {
    const context = await browser.newContext({ viewport, hasTouch: mobile, reducedMotion: 'reduce' });
    const page = await context.newPage(), trace = [], key = engine === 'webkit' && process.platform === 'darwin' ? 'Alt+Tab' : 'Tab';
    page.on('pageerror', error => runtimeProblems.push({ engine, name, kind: 'pageerror', message: error.message }));
    page.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, name, kind: 'console', message: message.text() }); });
    page.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, name, kind: 'http', status: response.status(), url: response.url() }); });
    page.on('requestfailed', request => { if (!/ABORTED|cancelled/i.test(request.failure()?.errorText || '')) runtimeProblems.push({ engine, name, kind: 'requestfailed', message: request.failure()?.errorText, url: request.url() }); });
    try { const details = await action(page, key, trace); results.push({ engine, test: name, viewport, pass: true, trace, details }); }
    catch (error) { trace.push({ name: 'failure-state', ...await state(page).catch(() => ({})) }); await screenshot(page, `${engine}-${name}-FAIL`).catch(() => {}); results.push({ engine, test: name, viewport, pass: false, trace, details: error.message }); }
    finally { await context.close(); await save(); }
  }
  for (const mobile of [true, false]) {
    const name = mobile ? 'phone-filter-resize-and-modal' : 'desktop-filter-and-resize';
    await check(name, mobile ? { width: 390, height: 844 } : { width: 1440, height: 900 }, mobile, async (page, key, trace) => {
      await page.goto(new URL('#awards', target).href, { waitUntil: 'networkidle' });
      if (mobile) await wheelTo(page, '.award-filter'); else await seek(page, `${config.awardFilters}[data-award-filter="all"]`, key);
      await settledProgress(page, trace, 'before-filter');
      for (const [filter, count] of [['all', 16], ['national', 5], ['provincial', 10], ['special', 1]]) {
        const selector = `${config.awardFilters}[data-award-filter="${filter}"]`;
        if (mobile) await tap(page, selector);
        else { await seek(page, selector, key, 8); await page.keyboard.press('Space'); }
        const s = await settledProgress(page, trace, `filter-${filter}`);
        assert(s.renderedAwards === count && s.countText === `共 ${count} 项` && s.selected.length === 1 && s.selected[0] === filter, '筛选数量/选择状态不一致');
        if (!mobile) assert(s.activeFilter === filter && s.activeFocusVisible, '原生Space筛选未保留键盘焦点');
      }
      await screenshot(page, `${engine}-${name}-special`);
      await page.setViewportSize(mobile ? { width: 1024, height: 768 } : { width: 1280, height: 700 });
      await settledProgress(page, trace, 'resize-width-and-height');
      await page.setViewportSize(mobile ? { width: 390, height: 700 } : { width: 1440, height: 900 });
      await settledProgress(page, trace, 'resize-return');
      if (mobile) {
        await page.goto(target.href, { waitUntil: 'networkidle' });
        await wheelTo(page, config.homeQrHero);
        const before = await settledProgress(page, trace, 'pre-modal-reading');
        await tap(page, config.homeQrHero);
        await page.waitForFunction(() => document.querySelector('#image-dialog')?.open && document.querySelector('#image-dialog')?.dataset.imageState === 'ready');
        await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
        const opened = await state(page); trace.push({ name: 'modal-open', ...opened });
        assert(opened.frozen && Math.abs(opened.logicalY - before.scrollY) <= 1 && Math.abs(opened.actualScale - before.expectedScale) <= tolerance, '弹窗打开改变了可见背景阅读比例');
        const image = await page.locator('#dialog-image').boundingBox();
        await page.mouse.move(image.x + image.width / 2, image.y + image.height / 2);
        await page.mouse.wheel(0, 500); await page.waitForTimeout(180);
        const wheel = await state(page); trace.push({ name: 'modal-native-wheel', ...wheel });
        assert(Math.abs(wheel.logicalY - before.scrollY) <= 1 && Math.abs(wheel.actualScale - before.expectedScale) <= tolerance, '弹窗滚轮改变了背景进度');
        await page.keyboard.press('Escape');
        await page.waitForFunction(() => !document.querySelector('#image-dialog').open);
        const closed = await settledProgress(page, trace, 'modal-closed');
        assert(!closed.frozen && Math.abs(closed.scrollY - before.scrollY) <= 1 && Math.abs(closed.actualScale - before.expectedScale) <= tolerance, '弹窗关闭未恢复背景阅读比例');
        await screenshot(page, `${engine}-${name}-closed`);
      }
      return { input: mobile ? 'native coordinate touchscreen taps' : key + ' / Space', filters: 4, resizeStates: 2, modal: mobile };
    });
  }
  for (const [name, route, viewport] of [
    ['project-long-reading', 'projects/jingcheng/', { width: 1280, height: 900 }],
    ['note-long-reading', 'notes/ai-workflow/', { width: 390, height: 844 }],
  ]) {
    await check(name, viewport, viewport.width < 960, async (page, key, trace) => {
      await page.goto(new URL(route, target).href, { waitUntil: 'networkidle' });
      const top = await settledProgress(page, trace, 'route-top');
      assert(top.scrollHeight > top.viewport.height * 1.5, '样本不是可滚动长页');
      await page.mouse.move(1, 1); await page.mouse.wheel(0, Math.round(viewport.height * 0.75));
      const middle = await settledProgress(page, trace, 'native-wheel');
      assert(middle.scrollY > top.scrollY + 100 && middle.actualScale > top.actualScale, '原生滚动未使进度前进');
      await page.setViewportSize({ width: viewport.width === 390 ? 768 : 1024, height: 700 });
      await settledProgress(page, trace, 'long-page-resize');
      await screenshot(page, `${engine}-${name}-resized`);
      return { route, nativeWheel: true, resize: true };
    });
  }
  await browser.close();
}
await save();
console.log(JSON.stringify({ count: results.length, passed: results.filter(r => r.pass).length, failed: results.filter(r => !r.pass).map(r => ({ engine: r.engine, test: r.test, details: r.details })), runtimeProblems, report: path.join(output, 'reading-results.json') }, null, 2));
if (results.length !== 8 || results.some(r => !r.pass) || runtimeProblems.length) process.exitCode = 1;
