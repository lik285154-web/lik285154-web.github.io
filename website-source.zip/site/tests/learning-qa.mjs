// Focused regression for learning, individual software statuses and the
// confirmed Lingqizhi awards. Run only after the implementation is frozen:
// node tests/learning-qa.mjs --url http://127.0.0.1:4322/ --label learning-local
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
import config from './qa-config.mjs';
import { inspectPublicCopy } from './public-copy.mjs';

const require = createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', arg('--label', 'learning-local'));
await fs.mkdir(output, { recursive: true });
const projectUrl = new URL('projects/lingqizhi/', target);
const results = [];
const runtimeProblems = [];
const assert = (ok, text) => { if (!ok) throw new Error(text); };
const softwareSelector = '.software-items article[data-research-kind="software"]';
const expectedAwards = [
  { id: 'craic-2026-national-first', level: '国家级', prize: '一等奖' },
  { id: 'craic-2026-guizhou-first', level: '省级', prize: '一等奖' },
  { id: 'raicom-2026-national-second', level: '国家级', prize: '二等奖' },
  { id: 'raicom-2026-guizhou-first', level: '省级', prize: '一等奖' },
  { id: 'ccdesign-2026-miao-national-third', level: '国家级', prize: '三等奖' },
  { id: 'ccdesign-2026-miao-guizhou-first', level: '省级', prize: '一等奖' },
];
const expectedSoftware = [
  { id: 'software-applications-2026', title: '苗医数字馆', status: '已登记' },
  { id: 'software-physics-accepted', title: '初中物理智能助学平台', status: '申请已受理' },
  { id: 'software-miao-health-accepted', title: '苗遗智卫智慧健康软件', status: '申请已受理' },
];
async function loadImage(image) {
  await image.evaluate(img => img.complete ? Promise.resolve() : new Promise((resolve, reject) => {
    img.addEventListener('load', resolve, { once: true });
    img.addEventListener('error', () => reject(new Error('图片加载失败')), { once: true });
  }));
  assert(await image.evaluate(img => img.naturalWidth > 0), '图片无有效像素');
}
async function visitSection(section) {
  const bounds = await section.evaluate(element => ({ top: element.getBoundingClientRect().top + scrollY, height: element.getBoundingClientRect().height }));
  for (let top = bounds.top; top < bounds.top + bounds.height; top += 550) {
    await section.page().evaluate(value => window.scrollTo({ top: value, behavior: 'instant' }), top);
    await section.page().waitForTimeout(80);
  }
  await section.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
  await section.page().waitForTimeout(850);
}
async function layoutFits(page, selectors) {
  const data = await page.evaluate(selectors => {
    const viewport = innerWidth;
    const outside = Array.from(document.querySelectorAll(selectors)).filter(element => {
      const box = element.getBoundingClientRect();
      return box.width > 0 && (box.x < -1 || box.right > viewport + 1);
    }).map(element => element.dataset.researchId || element.className || element.tagName);
    return { viewport, root: document.documentElement.scrollWidth, body: document.body.scrollWidth, outside };
  }, selectors);
  assert(data.root <= data.viewport + 1 && data.body <= data.viewport + 1 && !data.outside.length, `屏幕=${data.viewport}，页面=${data.root}，越界=${data.outside.join(', ')}`);
}
async function learningReadable(page) {
  const panels = await page.locator('.learning-program, [data-learning-hcip], [data-learning-language]').evaluateAll(elements => elements.map(element => ({ text: element.innerText.trim(), opacity: Number(getComputedStyle(element).opacity), display: getComputedStyle(element).display })));
  assert(panels.length === 3 && panels.every(panel => panel.text && panel.opacity > .95 && panel.display !== 'none'), '学习内容在当前模式下隐藏或透明');
  const running = await page.evaluate(() => document.getAnimations().filter(animation => animation.effect?.target instanceof Element && animation.effect.target.closest('#learning') && animation.playState === 'running' && Number(animation.effect.getTiming().duration) > 10).length);
  assert(!running, `学习区仍有 ${running} 个动画运行`);
}

for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  } catch (error) { results.push({ engine, test: '浏览器启动', pass: false, details: error.message.split('\n')[0] }); continue; }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, hasTouch: true });
  const page = await context.newPage();
  page.on('pageerror', error => runtimeProblems.push({ engine, kind: 'pageerror', message: error.message }));
  page.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, kind: 'console', message: message.text() }); });
  page.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, kind: 'http', message: `${response.status()} ${new URL(response.url()).pathname}` }); });
  page.on('requestfailed', request => { if (!/ABORTED|cancelled/i.test(request.failure()?.errorText || '')) runtimeProblems.push({ engine, kind: 'requestfailed', message: `${new URL(request.url()).pathname}: ${request.failure()?.errorText}` }); });
  async function check(test, run) {
    try { const details = await run(); results.push({ engine, test, pass: true, details: details || '' }); console.log(`PASS ${engine} ${test}`); }
    catch (error) { results.push({ engine, test, pass: false, details: String(error.message).slice(0, 600) }); console.log(`FAIL ${engine} ${test}: ${error.message}`); }
  }
  await page.goto(target.href, { waitUntil: 'networkidle' });
  await check('学习作为独立板块，辅修、备考和已通过状态清楚', async () => {
    const section = page.locator('#learning');
    assert(await section.count() === 1 && await section.locator('h2').count() === 1, '学习区或主标题缺失');
    assert(await section.evaluate(element => element.parentElement.tagName === 'MAIN'), '学习区没有独立展示');
    const program = (await section.locator('.learning-program').innerText()).replace(/\s+/g, '');
    assert(['华为', '辅修', 'AI视觉识别', '计算机视觉', 'CNN', 'YOLO'].every(term => program.includes(term)), '华为辅修或视觉学习内容缺失');
    const hcip = await section.locator('[data-learning-hcip]').innerText();
    assert(/HCIP/.test(hcip) && /备考中/.test(hcip) && !/已通过|已认证|已获证|持证/.test(hcip), 'HCIP备考被写成已取得认证');
    const language = await section.locator('[data-learning-language]').innerText();
    assert(/CET-6/.test(language) && /全国大学英语六级/.test(language) && /已通过/.test(language), '英语六级通过状态不清楚');
    return inspectPublicCopy(page);
  });
  await check('三项软著逐项独立展示，登记与受理不混淆', async () => {
    const cards = page.locator(softwareSelector);
    assert(await cards.count() === 3, '独立软著卡片应为三项');
    for (const expected of expectedSoftware) {
      const card = page.locator(`${softwareSelector}[data-research-id="${expected.id}"]`);
      assert(await card.count() === 1 && (await card.locator('h4').innerText()).includes(expected.title), `软件名称或独立卡片错误：${expected.title}`);
      assert(await card.getAttribute('data-research-status') === expected.status && (await card.locator(':scope > span').innerText()) === expected.status, `软件状态错误：${expected.title}`);
      assert(await card.locator('[data-research-certificate]').count() === (expected.status === '已登记' ? 1 : 0), `受理项使用了登记证书：${expected.title}`);
    }
    const summary = await page.locator('.software-summary').innerText();
    assert(/1\s*项已登记/.test(summary) && /2\s*项申请受理/.test(summary), '软著汇总与逐项状态不一致');
  });
  await check('桌面学习导航可用Enter准确定位', async () => {
    const link = page.locator('.desktop-nav [data-nav="learning"]');
    assert(await link.count() === 1 && await link.isVisible(), '桌面缺少学习导航');
    await link.focus(); await page.keyboard.press('Enter');
    await page.waitForTimeout(850);
    assert(new URL(page.url()).hash === '#learning', '学习导航未更新位置');
    const top = await page.locator('#learning').evaluate(element => element.getBoundingClientRect().top);
    assert(top >= -1 && top < 1000, '学习目标没有进入视口');
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await check('手机学习导航可触摸且选择后关闭菜单', async () => {
    await page.locator(config.menuButton).tap();
    await page.locator(config.navigation).waitFor({ state: 'visible' });
    const link = page.locator(`${config.navigation} a`).filter({ hasText: '学习' });
    assert(await link.count() === 1, '手机缺少学习导航');
    await link.tap();
    await page.waitForTimeout(850);
    assert(await page.locator(config.menuButton).getAttribute('aria-expanded') === 'false' && new URL(page.url()).hash === '#learning', '手机导航未关闭或未定位学习区');
  });
  await check('直接打开学习锚点可访问与刷新', async () => {
    // A same-document hash navigation legitimately has no HTTP response.
    // Start fresh to test a visitor opening the complete URL directly.
    await page.goto('about:blank');
    const response = await page.goto(new URL('#learning', target).href, { waitUntil: 'networkidle' });
    // WebKit may revalidate already cached static HTML with 304. The loaded
    // content and following reload still independently verify the page.
    assert(response && [200, 304].includes(response.status()) && await page.locator('#learning').count() === 1, `直接学习链接不可访问：HTTP ${response?.status()}`);
    const reload = await page.reload({ waitUntil: 'networkidle' });
    assert(reload.status() === 200 && new URL(page.url()).hash === '#learning', '学习链接刷新失败');
  });
  for (const width of [360, 390, 430, 768, 1440]) {
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await check(`${width}px 学习区和扩展导航无横向溢出`, async () => {
      const section = page.locator('#learning');
      await visitSection(section);
      await layoutFits(page, '.site-header, #learning, .learning-program, [data-learning-hcip], [data-learning-language]');
      if ([390, 1440].includes(width)) { await section.locator('h2').click(); await section.screenshot({ path: path.join(output, `${engine}-${width}-learning.png`) }); }
    });
    await check(`${width}px 三项软著名称与状态完整布局`, async () => {
      const section = page.locator('.software-research');
      await visitSection(section);
      await layoutFits(page, `${softwareSelector}, .software-summary`);
      if ([390, 1440].includes(width)) { await page.locator('#software-heading').click(); await section.screenshot({ path: path.join(output, `${engine}-${width}-software.png`) }); }
    });
  }
  for (const width of [390, 1440]) {
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await check(`${width}px 已登记软著原证书可查看与返回焦点`, async () => {
      const trigger = page.locator('[data-research-certificate]');
      await trigger.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await page.waitForTimeout(850);
      if (width < 768) await trigger.tap(); else { await trigger.focus(); await page.keyboard.press('Enter'); }
      const dialog = page.locator(config.lightboxDialog);
      await dialog.waitFor({ state: 'visible' });
      const image = dialog.locator('img');
      await loadImage(image);
      assert(await image.evaluate(img => /software-miao-museum-2026-registered\.webp/.test(img.currentSrc) && img.naturalWidth >= 1000), '打开了错误或未加载的登记证书');
      await page.keyboard.press('Escape');
      assert(!await dialog.isVisible() && await trigger.evaluate(element => element === document.activeElement), '软著弹窗关闭或焦点恢复失败');
    });
  }
  await check('首页标注小程序3国级3省级并链接到对应荣誉', async () => {
    const honors = page.locator('.mini-project-honors');
    assert(await honors.count() === 1 && /3\s*项国家级\s*\/\s*3\s*项省级一等奖/.test(await honors.innerText()), '小程序首页荣誉汇总不正确');
    assert(await page.locator(config.awardItems).count() === 16 && await page.locator('.award-project-link').count() === 6, '归属变更重复计数或缺少六项关联');
    const link = honors.locator('a');
    await link.click();
    await page.waitForURL(new URL('#project-awards', projectUrl).href, { waitUntil: 'networkidle', timeout: 10_000 });
    assert(new URL(page.url()).pathname === projectUrl.pathname && new URL(page.url()).hash === '#project-awards', '首页荣誉链接没有到达灵岐智对应区域');
  });
  await page.goto(projectUrl.href, { waitUntil: 'networkidle' });
  await check('灵岐智六项竞赛荣誉归属和赛级正确', async () => {
    const rows = page.locator('#project-awards [data-project-award]');
    const ids = await rows.evaluateAll(elements => elements.map(element => element.dataset.projectAward));
    assert(ids.length === 6 && new Set(ids).size === 6 && expectedAwards.every(award => ids.includes(award.id)), `项目关联荣誉错误：${ids.join(', ')}`);
    for (const award of expectedAwards) {
      const row = page.locator(`[data-project-award="${award.id}"]`);
      const text = (await row.innerText()).replace(/\s+/g, '');
      assert(text.includes(award.level + award.prize) && await row.locator(config.lightboxTriggers).count() === 1, `奖级或证书入口错误：${award.id}`);
    }
    return inspectPublicCopy(page);
  });
  await page.setViewportSize({ width: 390, height: 844 });
  for (const award of expectedAwards) {
    await check(`手机项目荣誉 ${award.id} 证书对应且可关闭`, async () => {
      const trigger = page.locator(`[data-project-award="${award.id}"] ${config.lightboxTriggers}`);
      await trigger.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await page.waitForTimeout(300);
      const source = await trigger.getAttribute('data-lightbox');
      assert(new URL(source, target).pathname.endsWith(`/media/awards/${award.id}.webp`), '关联奖项使用了别的证书');
      await trigger.tap();
      const dialog = page.locator(config.lightboxDialog);
      await dialog.waitFor({ state: 'visible' });
      const image = dialog.locator('img');
      await loadImage(image);
      assert(await image.evaluate((img, expected) => img.currentSrc === expected, new URL(source, target).href), '弹窗没有加载该项证书');
      await page.keyboard.press('Escape');
      assert(!await dialog.isVisible() && await trigger.evaluate(element => element === document.activeElement), '项目证书焦点未恢复');
    });
  }
  await visitSection(page.locator('#project-awards'));
  await page.locator('#project-awards h2').click();
  await page.locator('#project-awards').screenshot({ path: path.join(output, `${engine}-390-lingqizhi-awards.png`) });
  for (const width of [360, 1440]) {
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await check(`${width}px 灵岐智荣誉区无溢出`, async () => {
      const section = page.locator('#project-awards');
      await visitSection(section);
      await layoutFits(page, '#project-awards, #project-awards [data-project-award]');
      await section.locator('h2').click();
      await section.screenshot({ path: path.join(output, `${engine}-${width}-lingqizhi-awards.png`) });
    });
  }
  await check('灵岐智详情页直接刷新正常', async () => {
    const response = await page.reload({ waitUntil: 'networkidle' });
    assert(response.status() === 200 && await page.locator('#project-awards [data-project-award]').count() === 6, '项目页刷新后荣誉丢失');
  });
  for (const width of [1440, 390]) {
    await page.goto(projectUrl.href, { waitUntil: 'networkidle' });
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await check(`${width}px 从项目详情的学习导航返回首页`, async () => {
      if (width < 768) {
        await page.locator(config.menuButton).tap();
        await page.locator(config.navigation).waitFor({ state: 'visible' });
        await page.locator(`${config.navigation} a`).filter({ hasText: '学习' }).tap();
      } else { await page.locator('.desktop-nav [data-nav="learning"]').focus(); await page.keyboard.press('Enter'); }
      // Keyboard and touch activation can return before the new navigation
      // starts. Wait for the destination, not the old page's idle state.
      await page.waitForURL(new URL('#learning', target).href, { waitUntil: 'networkidle', timeout: 10_000 });
      assert(new URL(page.url()).pathname === target.pathname && new URL(page.url()).hash === '#learning' && await page.locator('#learning').count() === 1, '详情页学习导航使用了本页死锚点');
    });
  }
  await check('手机深色模式学习内容和软著可读', async () => {
    await page.locator('.theme-toggle').click();
    assert(await page.locator('html').getAttribute('data-theme') === 'dark', '没有切换到深色模式');
    await visitSection(page.locator('#learning'));
    await layoutFits(page, '#learning, .learning-program, [data-learning-hcip], [data-learning-language]');
    await page.locator('#learning').screenshot({ path: path.join(output, `${engine}-390-learning-dark.png`) });
    await visitSection(page.locator('.software-research'));
    await layoutFits(page, softwareSelector);
  });
  await check('暂停新学习动效仍可阅读全部内容', async () => {
    await page.locator(config.pauseMotion).click();
    assert(await page.locator(config.pauseMotion).getAttribute('aria-pressed') === 'true', '暂停未生效');
    await visitSection(page.locator('#learning'));
    await learningReadable(page);
  });
  await check('系统减少动态效果保留学习内容与状态', async () => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.evaluate(() => localStorage.removeItem('likun-motion'));
    await page.reload({ waitUntil: 'networkidle' });
    await visitSection(page.locator('#learning'));
    await learningReadable(page);
    assert(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior !== 'smooth'), '减少动效仍使用平滑滚动');
  });
  await check('新增区域和关联页面无运行时或资源错误', async () => {
    const errors = runtimeProblems.filter(problem => problem.engine === engine);
    assert(!errors.length, errors.slice(0, 6).map(error => `${error.kind}: ${error.message}`).join(' | '));
  });
  await browser.close();
}
const report = { timestamp: new Date().toISOString(), url: target.href, results, runtimeProblems, pass: results.every(result => result.pass) };
await fs.writeFile(path.join(output, 'learning-results.json'), JSON.stringify(report, null, 2));
console.log(`结果：${results.filter(result => result.pass).length}/${results.length} 通过。`);
if (!report.pass) process.exitCode = 1;
