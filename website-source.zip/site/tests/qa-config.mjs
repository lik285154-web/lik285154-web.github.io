// Selectors describe user-visible controls. Keep them independent of styling classes.
export default {
  menuButton: '.menu-toggle',
  navigation: '#mobile-nav',
  awardFilters: '[data-award-filter]',
  awardItems: '[data-award-item]',
  lightboxTriggers: '.certificate-button[data-lightbox]',
  lightboxDialog: '#image-dialog',
  lightboxClose: '[data-close-dialog]',
  pauseMotion: '[data-motion-toggle]',
};
