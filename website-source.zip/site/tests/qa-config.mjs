// Selectors describe user-visible controls. Keep them independent of styling classes.
export default {
  menuButton: '.menu-toggle',
  navigation: '#mobile-nav',
  awardFilters: '[data-award-filter]',
  awardItems: '[data-award-item]',
  lightboxTriggers: '.certificate-button[data-lightbox]',
  lightboxDialog: '#image-dialog',
  lightboxClose: '[data-close-dialog]',
  pauseMotion: '[data-motion-toggle]',
  homeQrSection: '#mini-program',
  homeQrHero: '[data-home-qr]',
  homeQrPanel: '[data-home-qr-panel]',
  homeQrDownload: '[data-home-qr-download]',
  projectStories: '.project-story',
  projectWorkflow: '#project-workflow',
  projectOutline: '.project-outline',
  researchCertificate: '[data-research-certificate]',
};
