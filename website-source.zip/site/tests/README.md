# 网站功能与发布测试

`qa.mjs` 检查真实浏览器中的主要风险：窄屏横向溢出、图片加载、导航与内部页面、菜单、荣誉筛选、证书弹窗、减少动态效果、运行时错误，以及静态产物中的凭据和私人材料。它不把实现逐行复写成测试。

启动预览服务器后运行：

```sh
node tests/qa.mjs --url http://127.0.0.1:4321/ --dist dist
```

GitHub Pages 的项目路径也必须单独验证，例如：

```sh
node tests/qa.mjs --url http://127.0.0.1:4321/likun/ --dist dist --label basepath
```

正式部署后再对公开 HTTPS 地址执行同一测试；此时省略 `--dist`。测试不会填写表单、修改在线内容、注册账号或发布站点。

脚本优先使用项目已安装的 Playwright；在 Codex 桌面可自动使用配套 runtime。其他电脑可安装开发依赖：`npm install --save-dev playwright`，再执行 `npx playwright install chromium webkit`。本机 Chrome 可以通过 `QA_CHROME_PATH` 指定。`PLAYWRIGHT_BROWSERS_PATH` 可以指定 Playwright 浏览器缓存目录。

测试输出保存在 `.qa-output/`，包括 JSON 结果和截图，不应发布到站点。对私人材料的扫描只记录风险类别与相对文件名，避免把可能的个人信息写进报告。

手机触屏和方形二维码回归可单独运行，避免为局部图片修改重复整个套件：

```sh
node tests/focused-qa.mjs http://127.0.0.1:4321/ --qr-only
```

省略 `--qr-only` 还会检查篮球的原生键盘与真实触摸操作、手机菜单的 Escape 和焦点恢复。最近一次实测结论见 [TEST-REPORT.md](./TEST-REPORT.md)。

头像、本人照片入口或实习产品背景修改后，可使用 `--hero-only` 对 1440 / 390 / 360 布局、图片加载、照片焦点恢复和实习产品来源做局部回归。

`--sprite-only` 只验证精灵键盘和触摸、暂停与减少动态效果；`--label public-sprite` 可将本次证据放入单独结果目录。公开站点和本地测试使用不同标签，避免覆盖历史结果。

如页面标记更新，可在 `qa-config.mjs` 中更新选择器；测试仍应围绕用户可见行为。

首页体验区、获奖排序、软著登记证书或项目故事修改后，运行专项回归：

```sh
node tests/revision-qa.mjs --url http://127.0.0.1:4322/ --label revision-local
```

该套件检查首页方形码的触摸与键盘入口、保存原图、创新大赛金银奖排序和筛选、已登记软著的对应证书、项目故事与流程导航、手机布局，以及 CSS / 鼠标装饰暂停和减少动效。主套件还会扫描每个页面的正文及弹窗说明，避免把内部核验措辞放进公开介绍。正式版本发布后再次运行，并使用 `--label revision-public` 保存独立证据。

需要便于查看的视觉证据时，运行 `node tests/capture-evidence.mjs --url http://127.0.0.1:4322/ --label revision-visual`。它单独保存 1440 / 390 首页、完整二维码卡片和精成流程视口截图，避免把长页面缩成无法阅读的图片；截图不计入自动功能检查数量。

只更新交接或测试文档时，可在发布前用 `node tests/verify-doc-publish.mjs --url https://lik285154-web.github.io/ --capture` 保存全部公开静态资源字节摘要，发布后执行同一命令并省略 `--capture` 比较。基线路径可用 `--baseline` 指定。这项比较不冒充完整浏览器测试；如网页资源出现差异，应按变更范围再测。
