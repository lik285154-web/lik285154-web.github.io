import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import config from './qa-config.mjs';

const require = createRequire(import.meta.url);
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const siteDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const target = new URL(arg('--url', 'http://127.0.0.1:4321/'));
const basePath = target.pathname.endsWith('/') ? target.pathname : `${target.pathname}/`;
const label = arg('--label', 'local');
const outputDir = path.join(siteDir, '.qa-output', label);
await fs.mkdir(outputDir, { recursive: true });
const results = [];
function record(engine, test, pass, details = '') {
  results.push({ engine, test, pass, details });
  console.log(`${pass ? 'PASS' : 'FAIL'} ${engine} ${test}${details ? ` — ${details}` : ''}`);
}
let pw;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', '/Users/mac/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'].filter(Boolean)) {
  try { pw = require(location); break; } catch {}
}
if (!pw) throw new Error('Playwright 未安装。参见 tests/README.md。');

async function safeCheck(engine, name, action) {
  try {
    const details = await action();
    record(engine, name, true, details || '');
  } catch (error) {
    record(engine, name, false, String(error.message).slice(0, 600));
  }
}
function assert(condition, message) { if (!condition) throw new Error(message); }
const runtimeProblems = [];
async function overflowAtCurrentViewport(page) {
  return page.evaluate(() => {
    const root = document.documentElement;
    return { viewport: innerWidth, scroll: root.scrollWidth, body: document.body.scrollWidth,
      offenders: Array.from(document.querySelectorAll('main *, header *, footer *')).filter(el => {
        const rect = el.getBoundingClientRect(); const style = getComputedStyle(el);
        return style.visibility !== 'hidden' && style.display !== 'none' && (rect.right > innerWidth + 2 || rect.left < -2) && !el.closest('[aria-hidden="true"]');
      }).slice(0, 10).map(el => `${el.tagName.toLowerCase()}${el.id ? `#${el.id}` : ''}`) };
  });
}
async function scrollThroughPage(page) {
  for (let y = 0; y < await page.evaluate(() => document.documentElement.scrollHeight); y += 650) {
    await page.evaluate(value => window.scrollTo(0, value), y);
    await page.waitForTimeout(60);
  }
  await page.waitForTimeout(150);
}
async function inspectPage(page, engine, route) {
  await page.goto(route.href, { waitUntil: 'networkidle', timeout: 30_000 });
  await page.evaluate(async () => { await document.fonts.ready; });
  await safeCheck(engine, `页面 ${route.pathname} 语义与资源`, async () => {
    const data = await page.evaluate(() => ({
      h1: document.querySelectorAll('h1').length,
      lang: document.documentElement.lang,
      main: Boolean(document.querySelector('main')),
      unnamed: Array.from(document.querySelectorAll('button')).filter(button => !button.textContent.trim() && !button.getAttribute('aria-label') && !button.getAttribute('aria-labelledby')).length,
      missingAlt: Array.from(document.images).filter(img => !img.hasAttribute('alt')).length,
      missingSize: Array.from(document.images).filter(img => (img.getAttribute('src') || img.getAttribute('srcset')) && (!img.hasAttribute('width') || !img.hasAttribute('height'))).length,
      serializationError: /\[object Object\]|\bundefined\b|\bNaN\b/.test(document.querySelector('main')?.textContent || ''),
      emptyFeatureDescriptions: Array.from(document.querySelectorAll('.feature-list p')).filter(p => !p.textContent.trim()).length,
    }));
    assert(data.h1 === 1 && data.main && data.lang, `h1=${data.h1}, main=${data.main}, lang=${data.lang}`);
    assert(!data.unnamed && !data.missingAlt && !data.missingSize, `无名称按钮=${data.unnamed}, 无alt图片=${data.missingAlt}, 无尺寸图片=${data.missingSize}`);
    assert(!data.serializationError && !data.emptyFeatureDescriptions, `序列化错误=${data.serializationError}, 空功能说明=${data.emptyFeatureDescriptions}`);
    await scrollThroughPage(page);
    const broken = await page.evaluate(() => Array.from(document.images).filter(img => (img.getAttribute('src') || img.getAttribute('srcset')) && (!img.complete || img.naturalWidth === 0)).map(img => new URL(img.currentSrc || img.src).pathname));
    assert(!broken.length, `未加载图片：${broken.join(', ')}`);
    return '标题、语义、按钮名称、图片尺寸与加载通过';
  });
  return page.locator('a[href]').evaluateAll(nodes => nodes.map(node => node.href));
}

for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    const options = { headless: true };
    const macChrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
    if (engine === 'chromium') {
      const customChrome = process.env.QA_CHROME_PATH;
      if (customChrome || (process.platform === 'darwin' && await fs.access(macChrome).then(() => true, () => false))) options.executablePath = customChrome || macChrome;
    }
    browser = await pw[engine].launch(options);
  } catch (error) {
    record(engine, '浏览器启动', false, error.message.split('\n')[0]);
    continue;
  }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  page.on('pageerror', error => runtimeProblems.push({ engine, kind: 'pageerror', message: error.message }));
  page.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, kind: 'console', message: message.text() }); });
  page.on('requestfailed', request => { if (request.failure()?.errorText !== 'net::ERR_ABORTED') runtimeProblems.push({ engine, kind: 'requestfailed', message: `${new URL(request.url()).pathname} ${request.failure()?.errorText}` }); });
  page.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, kind: 'http', message: `${response.status()} ${new URL(response.url()).pathname}` }); });
  const homeLinks = await inspectPage(page, engine, target);
  const routes = new Map();
  for (const href of homeLinks) {
    const url = new URL(href);
    if (url.origin !== target.origin || !url.pathname.startsWith(basePath) || url.pathname === target.pathname || /\.(png|jpg|jpeg|webp|svg|mp4|pdf|zip)$/i.test(url.pathname)) continue;
    url.hash = ''; url.search = '';
    routes.set(url.href, url);
  }
  await safeCheck(engine, '内部链接遵守部署路径', async () => {
    const outside = homeLinks.map(href => new URL(href)).filter(url => url.origin === target.origin && !url.pathname.startsWith(basePath));
    assert(!outside.length, `部署路径外的链接：${outside.map(url => url.pathname).join(', ')}`);
    return `内部详情页 ${routes.size} 个`;
  });
  for (const route of routes.values()) {
    const links = await inspectPage(page, engine, route);
    await safeCheck(engine, `详情页刷新 ${route.pathname}`, async () => {
      const response = await page.reload({ waitUntil: 'networkidle' });
      assert(response && response.status() === 200, `刷新状态 ${response?.status()}`);
      assert(await page.locator('main h1').count() === 1, '刷新后正文缺失');
    });
    for (const href of links) {
      const url = new URL(href);
      if (url.origin === target.origin && !url.pathname.startsWith(basePath)) record(engine, `详情页路径 ${route.pathname}`, false, `内部链接越过基路径：${url.pathname}`);
    }
    for (const width of [360, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await safeCheck(engine, `详情页 ${route.pathname} ${width}px 无溢出`, async () => {
        const overflow = await overflowAtCurrentViewport(page);
        assert(overflow.scroll <= width + 1 && overflow.body <= width + 1, `scrollWidth=${overflow.scroll}, bodyWidth=${overflow.body}, 可疑元素=${overflow.offenders.join(', ')}`);
      });
    }
  }
  await page.goto(target.href, { waitUntil: 'networkidle' });
  await safeCheck(engine, '锚点导航有实际目标', async () => {
    const invalid = await page.evaluate(() => Array.from(document.querySelectorAll('a[href]')).map(a => new URL(a.href)).filter(url => url.pathname === location.pathname && url.hash).filter(url => !document.getElementById(decodeURIComponent(url.hash.slice(1)))).map(url => url.hash));
    assert(!invalid.length, `空锚点：${invalid.join(', ')}`);
  });
  for (const width of [360, 390, 430, 768, 1440]) {
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(250);
    await safeCheck(engine, `${width}px 无横向溢出`, async () => {
      const overflow = await overflowAtCurrentViewport(page);
      assert(overflow.scroll <= width + 1 && overflow.body <= width + 1, `scrollWidth=${overflow.scroll}, bodyWidth=${overflow.body}, 可疑元素=${overflow.offenders.join(', ')}`);
      return `页面宽 ${overflow.scroll}px`;
    });
    if (width === 390 || width === 1440) {
      await scrollThroughPage(page);
      await page.evaluate(() => window.scrollTo(0, 0));
      await page.waitForTimeout(700);
      await page.screenshot({ path: path.join(outputDir, `${engine}-${width}-home.png`), fullPage: true });
      await page.screenshot({ path: path.join(outputDir, `${engine}-${width}-hero.png`) });
      for (const section of ['projects', 'awards']) {
        const element = page.locator(`#${section}`);
        if (await element.count()) {
          await element.scrollIntoViewIfNeeded();
          await page.waitForTimeout(350);
          await page.screenshot({ path: path.join(outputDir, `${engine}-${width}-${section}.png`) });
        }
      }
    }
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await safeCheck(engine, '手机菜单可开关与导航', async () => {
    const button = page.locator(config.menuButton);
    assert(await button.count() === 1, '未找到菜单控制按钮');
    await button.click();
    assert(await button.getAttribute('aria-expanded') === 'true', '菜单未报告展开');
    const nav = page.locator(config.navigation);
    await nav.waitFor({ state: 'visible', timeout: 3000 });
    assert(await nav.isVisible(), '展开菜单不可见');
    const firstLink = nav.locator('a[href]').first();
    assert(await firstLink.count(), '菜单没有导航链接');
    await firstLink.click();
    assert(await button.getAttribute('aria-expanded') === 'false', '选择导航后菜单未关闭');
  });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await safeCheck(engine, '荣誉筛选返回有效结果', async () => {
    const filters = page.locator(config.awardFilters);
    assert(await filters.count() >= 2, '未找到荣誉筛选');
    const counts = [];
    for (let i = 0; i < await filters.count(); i++) {
      await filters.nth(i).click();
      const visible = await page.locator(config.awardItems).evaluateAll(nodes => nodes.filter(node => !node.hidden && getComputedStyle(node).display !== 'none').length);
      assert(visible > 0, `筛选 ${i + 1} 显示空列表`);
      assert(await filters.nth(i).getAttribute('aria-pressed') === 'true', `筛选 ${i + 1} 缺少当前状态`);
      counts.push(visible);
    }
    assert(new Set(counts).size > 1, `所有筛选结果相同：${counts.join(', ')}`);
    await filters.first().click();
    return `各筛选数量 ${counts.join(' / ')}`;
  });
  await safeCheck(engine, '证书放大、键盘关闭及焦点返回', async () => {
    const triggers = page.locator(config.lightboxTriggers);
    assert(await triggers.count(), '未找到证书放大入口');
    for (let i = 0; i < Math.min(await triggers.count(), 3); i++) {
      const trigger = triggers.nth(i);
      await trigger.click();
      const dialog = page.locator(config.lightboxDialog);
      assert(await dialog.isVisible(), '证书弹窗不可见');
      const image = dialog.locator('img');
      if (await image.count()) {
        await image.evaluate(img => img.complete ? Promise.resolve() : new Promise((resolve, reject) => { img.addEventListener('load', resolve, { once: true }); img.addEventListener('error', reject, { once: true }); }));
        assert(await image.evaluate(img => img.naturalWidth > 0), '证书未加载');
      }
      await page.keyboard.press('Escape');
      assert(!await dialog.isVisible(), 'Escape 未关闭弹窗');
      assert(await trigger.evaluate(node => document.activeElement === node), '关闭后焦点未返回入口');
    }
  });
  await safeCheck(engine, '主题切换、持久保存与按钮名称', async () => {
    const before = await page.locator('html').getAttribute('data-theme') || 'light';
    const themeButton = page.locator('.theme-toggle');
    assert(await themeButton.count() === 1, '未找到主题切换');
    await themeButton.click();
    const after = await page.locator('html').getAttribute('data-theme');
    assert(after !== before, '主题没有变化');
    assert((await themeButton.getAttribute('aria-label'))?.includes(after === 'dark' ? '浅色' : '深色'), '按钮名称未对应下一步操作');
    await page.reload({ waitUntil: 'networkidle' });
    assert(await page.locator('html').getAttribute('data-theme') === after, '主题刷新后未保持');
    await page.screenshot({ path: path.join(outputDir, `${engine}-1440-theme.png`) });
    await page.locator('.theme-toggle').click();
  });
  await safeCheck(engine, '篮球互动给出结果', async () => {
    const ball = page.locator('[data-shot]');
    assert(await ball.count() === 1, '未找到篮球互动');
    await ball.click();
    await page.waitForFunction(() => /好球|命中|这一球/.test(document.querySelector('.shot-caption')?.textContent || ''), null, { timeout: 3000 });
  });
  await safeCheck(engine, '暂停按钮停止持续动效', async () => {
    const pause = page.locator(config.pauseMotion);
    assert(await pause.count() === 1, '未找到持续动效暂停入口');
    await pause.click();
    assert(await pause.getAttribute('aria-pressed') === 'true', '暂停状态未更新');
    const running = await page.evaluate(() => Array.from(document.querySelectorAll('main *')).filter(el => {
      const style = getComputedStyle(el);
      return style.animationName !== 'none' && style.animationPlayState !== 'paused';
    }).length);
    assert(running === 0, `仍有 ${running} 个持续动效运行`);
    await pause.click();
  });
  await safeCheck(engine, '减少动态效果生效', async () => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.reload({ waitUntil: 'networkidle' });
    const animations = await page.evaluate(() => {
      const active = Array.from(document.querySelectorAll('*')).filter(el => {
        const style = getComputedStyle(el);
        return style.animationName !== 'none' && style.animationPlayState !== 'paused' && style.animationDuration.split(',').some(duration => parseFloat(duration) > .01);
      });
      return { active: active.map(el => el.tagName.toLowerCase()).slice(0, 20), smooth: getComputedStyle(document.documentElement).scrollBehavior === 'smooth', hiddenContent: Array.from(document.querySelectorAll('main [data-reveal]')).filter(el => getComputedStyle(el).opacity === '0').length };
    });
    assert(!animations.active.length && !animations.smooth && !animations.hiddenContent, `仍运动=${animations.active.join(', ')}, smooth=${animations.smooth}, 隐藏内容=${animations.hiddenContent}`);
  });
  await safeCheck(engine, '运行时与网络无错误', async () => {
    const errors = runtimeProblems.filter(item => item.engine === engine);
    assert(!errors.length, errors.map(item => `${item.kind}: ${item.message}`).slice(0, 6).join(' | '));
  });
  await browser.close();
}

if (args.includes('--dist')) {
  await safeCheck('build', '公开产物无凭据和私人材料', async () => {
    const dist = path.resolve(siteDir, arg('--dist', 'dist'));
    async function walk(dir) {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      return (await Promise.all(entries.map(entry => entry.isDirectory() ? walk(path.join(dir, entry.name)) : path.join(dir, entry.name)))).flat();
    }
    const files = await walk(dist);
    assert(files.length > 0, '构建目录为空');
    const risks = [];
    const forbiddenName = /(^|\/)(\.env(?:\..*)?|id_rsa|id_ed25519|credentials[^/]*|私有材料索引)(\/|$)|\.(?:docx?|xlsx?|pptx?|qkdownloading)$/i;
    const tokenPatterns = [
      ['OpenAI key', /\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b/],
      ['GitHub token', /\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{25,}\b|\bgithub_pat_[A-Za-z0-9_]{35,}\b/],
      ['Private key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
      ['Identity number', /\b[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx]\b/],
      ['Local path', /\/Users\/mac\/Desktop\/介绍\//],
    ];
    for (const file of files) {
      const relative = path.relative(dist, file);
      if (forbiddenName.test(relative)) risks.push(`${relative}: 私人源文件/凭据文件名`);
      if (!/\.(?:html|js|css|json|txt|xml|svg)$/i.test(file)) continue;
      const text = await fs.readFile(file, 'utf8');
      for (const [name, pattern] of tokenPatterns) if (pattern.test(text)) risks.push(`${relative}: ${name}`);
    }
    assert(!risks.length, risks.join(' | '));
    return `${files.length} 个静态文件通过（不代替证书图片脱敏检查）`;
  });
}
const report = { timestamp: new Date().toISOString(), url: target.href, results, runtimeProblems, pass: results.every(result => result.pass) };
await fs.writeFile(path.join(outputDir, 'results.json'), JSON.stringify(report, null, 2));
console.log(`结果：${results.filter(result => result.pass).length}/${results.length} 通过。报告 ${path.join(outputDir, 'results.json')}`);
if (!report.pass) process.exitCode = 1;
