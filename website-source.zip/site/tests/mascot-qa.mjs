import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
import config from './qa-config.mjs';

// Exercise the visible control with native coordinates. A keyboard-only check
// cannot catch a moving hit area or decorative layers intercepting a pointer.
const require = createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
const label = arg('--label', 'mascot-local');
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', label);
await fs.mkdir(output, { recursive: true });
const results = [], runtimeProblems = [], coverage = [];
const assert = (ok, detail) => { if (!ok) throw new Error(detail); };
const spriteSelector = '[data-sprite-greet]';
const messageSelector = '[data-sprite-message]';

for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  } catch (error) { results.push({ engine, test: '浏览器启动', pass: false, details: error.message }); continue; }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, hasTouch: true });
  const page = await context.newPage();
  // Passive observations only: do not patch input handlers or animation methods.
  await page.addInitScript(() => {
    window.__mascotQa = { clicks: 0, trustedTouches: 0, animationIds: new WeakMap(), nextAnimationId: 1 };
    document.addEventListener('click', event => { if (event.target.closest?.('[data-sprite-greet]')) window.__mascotQa.clicks++; }, true);
    document.addEventListener('touchstart', event => { if (event.isTrusted) window.__mascotQa.trustedTouches++; }, { passive: true });
  });
  page.on('pageerror', error => runtimeProblems.push({ engine, type: 'pageerror', details: error.message }));
  page.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, type: 'console', details: message.text() }); });
  page.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, type: 'http', details: `${response.status()} ${new URL(response.url()).pathname}` }); });
  page.on('requestfailed', request => { if (!/ABORTED|cancelled/i.test(request.failure()?.errorText || '')) runtimeProblems.push({ engine, type: 'request', details: `${new URL(request.url()).pathname}: ${request.failure()?.errorText}` }); });
  async function check(test, run) {
    try { const details = await run(); results.push({ engine, test, pass: true, details: details ?? '' }); console.log(`PASS ${engine} ${test}`); }
    catch (error) { results.push({ engine, test, pass: false, details: String(error.message).slice(0, 1400) }); console.log(`FAIL ${engine} ${test}: ${error.message}`); }
  }
  async function home() {
    await page.goto('about:blank');
    const response = await page.goto(target.href, { waitUntil: 'networkidle' });
    assert(response && [200, 304].includes(response.status()), `首页未返回 HTML：${response?.status()}`);
    return response.status();
  }
  async function loadImage(locator) {
    await locator.evaluate(image => image.scrollIntoView({ block: 'center', behavior: 'instant' }));
    await locator.waitFor({ state: 'attached' });
    await page.waitForFunction(image => image.complete && image.naturalWidth > 0, await locator.elementHandle(), { timeout: 6000 });
    return locator.evaluate(image => ({ source: image.currentSrc, width: image.naturalWidth, height: image.naturalHeight, alt: image.alt }));
  }
  async function scene() { await page.locator('[data-playground]').evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' })); }
  async function frame() { await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))); }
  async function snapshot() {
    return page.evaluate(() => {
      const button = document.querySelector('[data-sprite-greet]');
      // A greeting may animate the button or any descendant. Hover transitions
      // are ambient pointer feedback, not an activation's finite action.
      const animations = button.getAnimations({ subtree: true }).filter(animation =>
        !(typeof CSSTransition !== 'undefined' && animation instanceof CSSTransition) &&
        animation.playState === 'running' && animation.effect?.getTiming().iterations === 1 && Number(animation.effect?.getTiming().duration) > 50);
      return { message: document.querySelector('[data-sprite-message]').textContent, clicks: window.__mascotQa.clicks, box: button.getBoundingClientRect().toJSON(), animations: animations.map(animation => {
        const store = window.__mascotQa;
        if (!store.animationIds.has(animation)) store.animationIds.set(animation, store.nextAnimationId++);
        return { id: store.animationIds.get(animation), currentTime: animation.currentTime, playState: animation.playState };
      }) };
    });
  }
  // Points are based on the image's rendered object-fit rectangle, not the
  // oversized button or its implementation-specific visual wrappers.
  async function point(rx, ry) {
    return page.locator(`${spriteSelector} img`).evaluate((image, fraction) => {
      const box = image.getBoundingClientRect();
      const width = Math.min(box.width, box.height * image.naturalWidth / image.naturalHeight);
      const height = width * image.naturalHeight / image.naturalWidth;
      return { x: box.x + (box.width - width) / 2 + width * fraction.rx, y: box.y + (box.height - height) / 2 + height * fraction.ry };
    }, { rx, ry });
  }
  async function hit(position, selector = spriteSelector) {
    const data = await page.evaluate(({ position, selector }) => {
      const element = document.elementFromPoint(position.x, position.y);
      return { correct: !!element?.closest?.(selector), tag: element?.tagName, class: element?.className?.baseVal || element?.className };
    }, { position, selector });
    assert(data.correct, `屏上坐标被其他元素拦截：${JSON.stringify(data)}`);
    return data;
  }
  async function activate(position, width, hold = false) {
    await hit(position);
    const before = await snapshot();
    if (width < 500) await page.touchscreen.tap(position.x, position.y);
    else {
      await page.mouse.move(position.x, position.y);
      if (hold) { await page.mouse.down(); await page.waitForTimeout(120); await page.mouse.up(); }
      else await page.mouse.click(position.x, position.y);
    }
    await frame();
    const after = await snapshot();
    assert(after.clicks === before.clicks + 1 && after.message !== before.message, '每次原生输入应触发一次即时文案');
    assert(after.animations.length === 1 && after.animations[0].id !== before.animations[0]?.id, '本次激活没有新的可见反馈动作');
    assert(Math.abs(after.box.x - before.box.x) < .75 && Math.abs(after.box.y - before.box.y) < .75, '点击期间命中区域仍在移动');
    return { position, message: after.message, actionId: after.animations[0].id, heldMs: hold ? 120 : 0 };
  }
  async function noOverflow() {
    const data = await page.evaluate(() => ({ width: innerWidth, root: document.documentElement.scrollWidth, body: document.body.scrollWidth }));
    assert(data.root <= data.width + 1 && data.body <= data.width + 1, JSON.stringify(data));
    return data;
  }
  async function openAndClose(trigger, width) {
    await trigger.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
    await page.waitForTimeout(850);
    const box = await trigger.boundingBox(); assert(box, '图片入口不可见');
    const beforeSource = new URL(await trigger.getAttribute('data-lightbox'), target).href;
    if (width < 500) await page.touchscreen.tap(box.x + box.width / 2, box.y + box.height / 2);
    else { await trigger.focus(); await page.keyboard.press('Enter'); }
    await page.locator(config.lightboxDialog).waitFor({ state: 'visible' });
    const image = await loadImage(page.locator('#dialog-image'));
    assert(image.source === beforeSource && image.width > 0, '图片来源与入口不一致');
    await page.keyboard.press('Escape');
    await page.waitForFunction(button => !document.querySelector('#image-dialog').open && document.activeElement === button && document.body.style.overflow === '', await trigger.elementHandle(), { timeout: 2000 });
    return image;
  }
  try {
    for (const width of [1440, 1024, 768, 390, 360]) {
      await page.setViewportSize({ width, height: width < 500 ? 844 : 1000 });
      await home(); await scene();
      await check(`${width}px 关于我为主视觉后第一正文、精灵加载及布局`, async () => {
        const image = await loadImage(page.locator(`${spriteSelector} img`));
        const data = await page.evaluate(() => ({ first: document.querySelector('main > section[id]')?.id, aboutTop: document.querySelector('#about').getBoundingClientRect().top, heroBottom: document.querySelector('.hero').getBoundingClientRect().bottom, desktopFirst: document.querySelector('.desktop-nav a')?.getAttribute('href'), mobileFirst: document.querySelector('#mobile-nav a')?.getAttribute('href'), scrollPrompt: document.querySelector('.scroll-prompt')?.getAttribute('href'), draggable: document.querySelector('[data-sprite-greet] img').draggable }));
        assert(data.first === 'about' && data.aboutTop >= data.heroBottom - 1 && data.desktopFirst === '#about' && data.mobileFirst === '#about' && data.scrollPrompt === '#about' && !data.draggable && image.width >= 500, JSON.stringify(data));
        await noOverflow(); return data;
      });
      for (const [name, rx, ry] of [['头部', .5, .40], ['身体', .5, .65], ['左侧头缘', .20, .40], ['右侧头缘', .80, .40], ['脚部', .5, .89]]) {
        await check(`${width}px ${name}${width < 500 ? '真实触摸' : '坐标按住120ms'}响应`, async () => {
          await scene(); return activate(await point(rx, ry), width, width >= 500);
        });
      }
      await check(`${width}px 固定坐标六连点均有文字与新动作`, async () => {
        await scene(); const fixed = await point(.5, .63), details = [];
        for (let index = 0; index < 6; index++) { details.push(await activate(fixed, width)); await page.waitForTimeout(100); }
        return details;
      });
      if (width >= 500) await check(`${width}px 鼠标横移仍命中身体且外部按钮稳定`, async () => {
        await scene(); const before = await snapshot(), bounds = await page.locator('[data-playground]').boundingBox();
        await page.mouse.move(bounds.x + 12, bounds.y + bounds.height / 2);
        await page.mouse.move(bounds.x + bounds.width - 12, bounds.y + bounds.height / 2, { steps: 16 });
        await page.waitForTimeout(220); const after = await snapshot();
        assert(Math.abs(before.box.x - after.box.x) < .75 && Math.abs(before.box.y - after.box.y) < .75 && Math.abs(before.box.width - after.box.width) < .75, '鼠标移动改变了按钮命中区域');
        return activate(await point(.5, .63), width, true);
      });
      if (engine === 'chromium' && width < 500) await check(`${width}px 浏览器真实触屏滑动不会误打招呼`, async () => {
        await scene(); const start = await point(.5, .63); await hit(start);
        const before = await snapshot(), scrollBefore = await page.evaluate(() => scrollY), touchBefore = await page.evaluate(() => window.__mascotQa.trustedTouches);
        const session = await context.newCDPSession(page);
        try {
          await session.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: start.x, y: start.y, radiusX: 2, radiusY: 2, force: 1, id: 1 }] });
          for (let step = 1; step <= 8; step++) { await session.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: start.x, y: start.y - step * 20, radiusX: 2, radiusY: 2, force: 1, id: 1 }] }); await page.waitForTimeout(20); }
          await session.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
        } finally { await session.detach(); }
        await page.waitForTimeout(200); const after = await snapshot(), scrollAfter = await page.evaluate(() => scrollY), touchAfter = await page.evaluate(() => window.__mascotQa.trustedTouches);
        assert(after.clicks === before.clicks && after.message === before.message && touchAfter > touchBefore && scrollAfter > scrollBefore + 30, `滑动误触或未形成真实滚动：${JSON.stringify({ before: before.clicks, after: after.clicks, scrollBefore, scrollAfter, touchBefore, touchAfter })}`);
        return { trustedTouch: true, scrollDistance: scrollAfter - scrollBefore, clickDelta: after.clicks - before.clicks };
      });
      await scene(); await page.waitForTimeout(80);
      await page.locator('[data-playground]').screenshot({ path: path.join(output, `${engine}-${width}-sprite.png`), animations: 'disabled' });
      coverage.push({ engine, width, input: width < 500 ? 'trusted touchscreen tap' : 'native mouse coordinates and 120ms hold' });
    }
    await check('精灵原生 Enter 和 Space 均即时响应且焦点清晰', async () => {
      await page.setViewportSize({ width: 1440, height: 1000 }); await home();
      const button = page.locator(spriteSelector); await button.focus();
      const details = [];
      for (const key of ['Enter', 'Space']) {
        const before = await snapshot(); await page.keyboard.press(key); await frame(); const after = await snapshot();
        assert(after.message !== before.message && after.clicks === before.clicks + 1 && after.animations.length === 1 && after.animations[0].id !== before.animations[0]?.id, `${key} 无即时文案或新动作`);
        details.push({ key, message: after.message });
      }
      const focus = await button.evaluate(element => ({ active: document.activeElement === element, outline: getComputedStyle(element).outlineStyle, outlineWidth: parseFloat(getComputedStyle(element).outlineWidth) }));
      assert(focus.active && focus.outline !== 'none' && focus.outlineWidth > 0, '键盘焦点不可见'); return details;
    });
    for (const width of [1440, 390]) await check(`${width}px 关于导航及首正文可读`, async () => {
      await page.setViewportSize({ width, height: width < 500 ? 844 : 1000 }); await home();
      if (width < 500) { await page.locator(config.menuButton).tap(); await page.locator('#mobile-nav a[href="#about"]').tap(); }
      else { await page.locator('.desktop-nav a[href="#about"]').focus(); await page.keyboard.press('Enter'); }
      await page.waitForURL(new URL('#about', target).href, { waitUntil: 'networkidle' }); await page.waitForTimeout(950);
      const heading = await page.locator('#about .section-heading h2').boundingBox(), header = await page.locator('.site-header').boundingBox();
      assert(heading && heading.y >= header.y + header.height - 2 && heading.y < (width < 500 ? 844 : 1000) - 40, '关于标题被导航遮挡');
      if (width < 500) assert(await page.locator(config.menuButton).getAttribute('aria-expanded') === 'false', '关于导航后菜单未关闭');
      for (const element of await page.locator('#about [data-reveal-state]').all()) await element.evaluate(node => node.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await page.waitForTimeout(950); await noOverflow();
      await page.locator('#about').screenshot({ path: path.join(output, `${engine}-${width}-about.png`), animations: 'disabled' });
    });
    await page.setViewportSize({ width: 390, height: 844 }); await home();
    await check('手机关于本人照片入口打开与焦点恢复', () => openAndClose(page.locator('.photo-link'), 390));
    await check('手机首屏小程序码入口仍可用', async () => {
      const image = await openAndClose(page.locator(config.homeQrHero), 390);
      assert(image.width >= 500 && image.width === image.height && /灵岐智|小程序码/.test(image.alt), '首屏码不是清晰方形小程序码'); return image;
    });
    await check('手机二维码正文入口仍可用', () => openAndClose(page.locator(config.homeQrPanel), 390));
    await check('手机篮球独立命中且不触发精灵', async () => {
      await scene(); const ball = page.locator('[data-shot]'), box = await ball.boundingBox(); assert(box, '篮球不可见');
      const position = { x: box.x + box.width / 2, y: box.y + box.height / 2 }; await hit(position, '[data-shot]');
      const before = await snapshot(), caption = await page.locator('.shot-caption').textContent();
      await page.touchscreen.tap(position.x, position.y);
      await page.waitForFunction(previous => document.querySelector('.shot-caption').textContent !== previous, caption, { timeout: 2000 });
      const after = await snapshot(); assert(after.clicks === before.clicks && after.message === before.message, '精灵命中区域抢占篮球');
      await page.waitForFunction(() => !document.querySelector('[data-shot]').classList.contains('shooting'), null, { timeout: 2500 });
    });
    await check('打招呼中暂停、暂停再点、恢复后的文字动作状态正确', async () => {
      await home(); await scene(); await activate(await point(.5, .63), 390);
      const message = await page.locator(messageSelector).textContent();
      await page.locator(config.pauseMotion).focus(); await page.keyboard.press('Enter'); await frame();
      assert((await snapshot()).animations.length === 0 && await page.locator(messageSelector).textContent() === message, '暂停未取消动作或丢失文字');
      await page.locator(spriteSelector).focus(); const before = await snapshot(); await page.keyboard.press('Enter'); await frame(); const paused = await snapshot();
      assert(paused.clicks === before.clicks + 1 && paused.message !== before.message && paused.animations.length === 0, '暂停再次激活缺少静态反馈或仍播放动作');
      await page.locator(config.pauseMotion).focus(); await page.keyboard.press('Enter'); await frame();
      assert((await snapshot()).animations.length === 0, '恢复动效意外重放旧动作');
      await scene(); await activate(await point(.5, .63), 390); await page.waitForTimeout(750);
      assert((await snapshot()).animations.length === 0, '动作结束后仍遗留持续播放');
    });
    await check('系统减少动效时仍可触摸和键盘反馈', async () => {
      await page.emulateMedia({ reducedMotion: 'reduce' }); await home(); await scene();
      let before = await snapshot(); const position = await point(.5, .63); await hit(position); await page.touchscreen.tap(position.x, position.y); await frame(); let after = await snapshot();
      assert(after.message !== before.message && after.clicks === before.clicks + 1 && after.animations.length === 0, '减少动效的触摸反馈不正确');
      await page.locator(spriteSelector).focus(); before = await snapshot(); await page.keyboard.press('Space'); await frame(); after = await snapshot();
      assert(after.message !== before.message && after.animations.length === 0, '减少动效的键盘反馈不正确');
      await noOverflow(); await page.locator('[data-playground]').screenshot({ path: path.join(output, `${engine}-390-reduced-sprite.png`), animations: 'disabled' });
      await page.emulateMedia({ reducedMotion: 'no-preference' });
    });
    await home();
    const routes = await page.locator('.project-card[href], .project-row[href]').evaluateAll(elements => [...new Set(elements.map(element => new URL(element.href).pathname))]);
    await check('四个项目手机轻量复验入口完整', () => assert(routes.length >= 4, `项目入口仅 ${routes.length}`));
    for (const route of routes) await check(`390px 项目 ${route} 图片布局及首证书轻量复验`, async () => {
      const response = await page.goto(new URL(route, target).href, { waitUntil: 'networkidle' });
      assert(response && [200, 304].includes(response.status()) && await page.locator('main h1').count() === 1, '项目直达未返回正文');
      const images = [];
      for (const image of await page.locator('main img').all()) images.push(await loadImage(image));
      await noOverflow();
      const certificate = page.locator(`#project-awards ${config.lightboxTriggers}`).first();
      if (await certificate.count()) await openAndClose(certificate, 390);
      const qr = page.locator('.qr-section .qr-image[data-lightbox]');
      if (await qr.count()) await openAndClose(qr, 390);
      await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
      return { images: images.length, certificate: await certificate.count(), qr: await qr.count() };
    });
    await check('本轮受影响页面无运行时或网络错误', () => { const errors = runtimeProblems.filter(problem => problem.engine === engine); assert(!errors.length, JSON.stringify(errors.slice(0, 8))); });
  } finally { await context.close(); await browser.close(); }
}
const report = { timestamp: new Date().toISOString(), url: target.href, scope: 'Mascot input and feedback, About ordering, nearby entries, mobile project smoke', touchDragCoverage: 'Chromium trusted CDP touchStart/move/end at 360 and 390; WebKit uses native trusted taps. No synthetic touch events counted as real drag.', coverage, results, runtimeProblems, pass: results.every(result => result.pass) };
await fs.writeFile(path.join(output, 'mascot-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(`结果：${results.filter(result => result.pass).length}/${results.length} 通过。`);
if (!report.pass) process.exitCode = 1;
