import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
const require = createRequire(import.meta.url);
let playwright;
for (const modulePath of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(modulePath); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const target = new URL(process.argv[2] || 'http://127.0.0.1:4322/');
const qrOnly = process.argv.includes('--qr-only');
const spriteOnly = process.argv.includes('--sprite-only');
const heroOnly = process.argv.includes('--hero-only') || spriteOnly;
const labelIndex = process.argv.indexOf('--label');
const resultLabel = labelIndex >= 0 ? process.argv[labelIndex + 1] : heroOnly ? 'avatar-local' : 'final-local';
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', resultLabel);
await fs.mkdir(output, { recursive: true });
const results = [];
const assert = (ok, message) => { if (!ok) throw new Error(message); };
for (const engine of ['chromium', 'webkit']) {
  const browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  const context = await browser.newContext(heroOnly ? { viewport: { width: 1440, height: 1000 }, hasTouch: true } : { viewport: { width: 360, height: 844 }, isMobile: true, hasTouch: true });
  const page = await context.newPage();
  async function check(name, run) {
    try { await run(); results.push({ engine, test: name, pass: true }); console.log(`PASS ${engine} ${name}`); }
    catch (error) { results.push({ engine, test: name, pass: false, details: error.message }); console.log(`FAIL ${engine} ${name}: ${error.message}`); }
  }
  await page.goto(target.href, { waitUntil: 'networkidle' });
  if (heroOnly) {
    for (const width of spriteOnly ? [] : [1440, 390, 360]) {
      await page.setViewportSize({ width, height: width === 1440 ? 1000 : 844 });
      await page.evaluate(() => window.scrollTo(0, 0));
      await check(`${width}px 数字头像已加载且首页无溢出`, async () => {
        const image = page.locator('.has-avatar .character-card img');
        assert(await image.count() === 1, '首屏没有接入数字头像');
        await image.evaluate(img => img.complete ? Promise.resolve() : new Promise((resolve, reject) => { img.addEventListener('load', resolve, { once: true }); img.addEventListener('error', reject, { once: true }); }));
        assert(await image.evaluate(img => img.naturalWidth >= 500 && /3D|精灵|吉祥物|数字/.test(img.alt)), '头像或吉祥物未加载或无对应描述');
        assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), '头像接入后首页横向溢出');
        await page.waitForTimeout(150);
        await page.screenshot({ path: path.join(output, `${engine}-${width}-hero.png`) });
      });
      if (width < 500) {
        await check(`${width}px 实习产品资料与来源可读`, async () => {
          const product = page.locator('.experience-product');
          await product.scrollIntoViewIfNeeded();
          const data = await product.evaluate(el => ({ rect: el.getBoundingClientRect().toJSON(), text: el.textContent, links: Array.from(el.querySelectorAll('a')).map(a => ({ href: a.href, rect: a.getBoundingClientRect().toJSON() })) }));
          assert(data.rect.x >= -1 && data.rect.right <= width + 1, '实习产品资料超出屏幕');
          assert(data.text.includes('Meowdoku') && data.text.includes('累计下载') && data.text.includes('2026 年 10 月 20 日'), '产品数据缺少口径/查阅日期');
          assert(data.links.length === 2 && data.links.every(a => a.href.startsWith('https://') && a.rect.x >= -1 && a.rect.right <= width + 1), '来源链接缺失或越过屏幕');
          await page.screenshot({ path: path.join(output, `${engine}-${width}-internship.png`) });
        });
      }
    }
    if (!spriteOnly) await check('本人照片打开、正确描述及 Escape 焦点返回', async () => {
      const trigger = page.locator('.photo-link');
      await trigger.click();
      const dialog = page.locator('#image-dialog');
      await dialog.waitFor({ state: 'visible' });
      const image = dialog.locator('img');
      await image.evaluate(img => img.complete ? Promise.resolve() : new Promise((resolve, reject) => { img.addEventListener('load', resolve, { once: true }); img.addEventListener('error', reject, { once: true }); }));
      assert(await image.evaluate(img => img.naturalWidth > 0 && img.alt.includes('本人照片')), '原照未加载或描述错误');
      await page.keyboard.press('Escape');
      assert(!await dialog.isVisible(), '原照未关闭');
      assert(await trigger.evaluate(button => button === document.activeElement), '原照焦点没有返回入口');
    });
    await page.setViewportSize({ width: 360, height: 844 });
    await check('360px 精灵 Enter 与触摸响应、暂停时保留文字反馈', async () => {
      const sprite = page.locator('[data-sprite-greet]');
      const message = page.locator('[data-sprite-message]');
      assert(await sprite.count() === 1, '精灵互动缺失');
      // Native scrolling does not wait for the intentionally floating control to stop.
      await sprite.evaluate(button => button.scrollIntoView({ block: 'center', behavior: 'instant' }));
      let before = await message.textContent();
      await sprite.focus(); await page.keyboard.press('Enter');
      await page.waitForFunction(previous => document.querySelector('[data-sprite-message]')?.textContent !== previous, before, { timeout: 3000 });
      assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), '精灵招呼文字造成横向溢出');
      await page.locator('.hero-scene').screenshot({ path: path.join(output, `${engine}-360-sprite-greeting.png`) });
      await page.waitForFunction(() => !document.querySelector('[data-sprite-greet]')?.classList.contains('greeting'), null, { timeout: 3000 });
      before = await message.textContent();
      const rect = await sprite.boundingBox(); assert(rect, '精灵不可见');
      await page.touchscreen.tap(rect.x + rect.width / 2, rect.y + rect.height / 2);
      await page.waitForFunction(previous => document.querySelector('[data-sprite-message]')?.textContent !== previous, before, { timeout: 3000 });
      await page.waitForFunction(() => !document.querySelector('[data-sprite-greet]')?.classList.contains('greeting'), null, { timeout: 3000 });
      await page.locator('[data-motion-toggle]').click();
      before = await message.textContent();
      await sprite.focus(); await page.keyboard.press('Enter');
      assert(await message.textContent() !== before, '暂停时没有精灵文字反馈');
      assert(!await sprite.evaluate(button => button.classList.contains('greeting')), '暂停时精灵仍跳动');
      await page.emulateMedia({ reducedMotion: 'reduce' });
      await page.reload({ waitUntil: 'networkidle' });
      before = await message.textContent();
      await sprite.focus(); await page.keyboard.press('Enter');
      assert(await message.textContent() !== before, '减少动效时没有文字反馈');
      assert(!await sprite.evaluate(button => button.classList.contains('greeting')), '减少动效时精灵仍跳动');
    });
    await browser.close();
    continue;
  }
  if (!qrOnly) {
  await check('篮球键盘 Enter 与触摸中心响应', async () => {
    const ball = page.locator('[data-shot]');
    await ball.focus(); await page.keyboard.press('Enter');
    await page.waitForFunction(() => /好球|命中|这一球/.test(document.querySelector('.shot-caption')?.textContent || ''), null, { timeout: 3000 });
    await page.waitForTimeout(100);
    const before = await page.locator('.shot-caption').textContent();
    const rect = await ball.boundingBox(); assert(rect, '篮球不可见');
    await page.touchscreen.tap(rect.x + rect.width / 2, rect.y + rect.height / 2);
    await page.waitForFunction(previous => {
      const text = document.querySelector('.shot-caption')?.textContent || '';
      return text !== previous && /好球|命中|这一球/.test(text);
    }, before, { timeout: 3000 });
  });
  await check('手机菜单可触摸打开并用 Escape 关闭', async () => {
    await page.locator('.menu-toggle').tap();
    await page.locator('#mobile-nav').waitFor({ state: 'visible' });
    await page.keyboard.press('Escape');
    assert(await page.locator('.menu-toggle').getAttribute('aria-expanded') === 'false', '菜单没有关闭');
    assert(await page.locator('.menu-toggle').evaluate(button => button === document.activeElement), '菜单关闭后焦点未恢复');
  });
  }
  await page.goto(new URL('projects/lingqizhi/', target).href, { waitUntil: 'networkidle' });
  for (const width of [360, 390]) {
  await page.setViewportSize({ width, height: 844 });
  await check(`${width}px 小程序码可放大、图像保持比例、关闭恢复焦点`, async () => {
    const trigger = page.locator('.qr-image');
    assert(await trigger.count() === 1, '小程序码入口缺失');
    await trigger.tap();
    const dialog = page.locator('#image-dialog');
    await dialog.waitFor({ state: 'visible' });
    const img = dialog.locator('img');
    await img.evaluate(image => image.complete ? Promise.resolve() : new Promise((resolve, reject) => { image.onload = resolve; image.onerror = reject; }));
    const dimensions = await img.evaluate(image => ({ width: image.getBoundingClientRect().width, height: image.getBoundingClientRect().height, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight }));
    const box = await dialog.boundingBox();
    assert(box && box.x >= -1 && box.x + box.width <= width + 1 && box.height <= 845, '手机弹窗越过屏幕边界');
    assert(dimensions.naturalWidth >= 500, '小程序码原图分辨率不足');
    assert(Math.abs(dimensions.width / dimensions.height - dimensions.naturalWidth / dimensions.naturalHeight) < .02, '小程序码被拉伸');
    if (qrOnly) assert(dimensions.naturalWidth === dimensions.naturalHeight && dimensions.width > 280, '弹窗没有采用清晰的方形小程序码');
    await page.screenshot({ path: path.join(output, `${engine}-${width}-qr-dialog.png`) });
    await page.keyboard.press('Escape');
    assert(!await dialog.isVisible(), 'Escape 没有关闭弹窗');
    assert(await trigger.evaluate(button => button === document.activeElement), '二维码弹窗焦点未恢复');
  });
  }
  await check('保存小程序码下载入口有完整原图', async () => {
    const link = page.locator('.qr-section a[download]');
    assert(await link.count() === 1, '缺少原图保存链接');
    const response = await context.request.get(new URL(await link.getAttribute('href'), target).href);
    assert(response.status() === 200 && /image/.test(response.headers()['content-type']), '保存链接没有返回原图');
  });
  await browser.close();
}
await fs.writeFile(path.join(output, heroOnly ? 'hero-regression-results.json' : qrOnly ? 'qr-regression-results.json' : 'focused-results.json'), JSON.stringify({ timestamp: new Date().toISOString(), url: target.href, results }, null, 2));
if (results.some(result => !result.pass)) process.exitCode = 1;
