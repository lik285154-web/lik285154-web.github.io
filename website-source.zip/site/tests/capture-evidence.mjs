import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';

const require = createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', arg('--label', 'revision-visual'));
await fs.mkdir(output, { recursive: true });
const captures = [];
for (const engine of ['chromium', 'webkit']) {
  const browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  const context = await browser.newContext();
  const page = await context.newPage();
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: width === 1440 ? 1000 : 844 });
    await page.goto(target.href, { waitUntil: 'networkidle' });
    await page.evaluate(async () => { await document.fonts.ready; });
    await page.waitForTimeout(1000);
    const heroFile = `${engine}-${width}-hero.png`;
    await page.screenshot({ path: path.join(output, heroFile) });
    captures.push(heroFile);
    const panel = page.locator('.mini-program-panel');
    await panel.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
    await page.waitForTimeout(1000);
    // A normal page preview should not show a keyboard focus ring carried from
    // the functional dialog test. The heading has no action or side effect.
    await panel.locator('h2').click();
    const qrFile = `${engine}-${width}-home-qr-panel.png`;
    await panel.screenshot({ path: path.join(output, qrFile) });
    captures.push(qrFile);
    await page.goto(new URL('projects/jingcheng/', target).href, { waitUntil: 'networkidle' });
    await page.locator('#project-workflow').evaluate(element => element.scrollIntoView({ block: 'start', behavior: 'instant' }));
    await page.waitForTimeout(1000);
    const workflowFile = `${engine}-${width}-jingcheng-workflow.png`;
    await page.screenshot({ path: path.join(output, workflowFile) });
    captures.push(workflowFile);
  }
  await browser.close();
}
await fs.writeFile(path.join(output, 'captures.json'), JSON.stringify({ timestamp: new Date().toISOString(), url: target.href, captures, note: '截图用于人工视觉复核；不计入自动功能测试通过数。' }, null, 2));
console.log(`已保存 ${captures.length} 张视觉复核截图：${output}`);
