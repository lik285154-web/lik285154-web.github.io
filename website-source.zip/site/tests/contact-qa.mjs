import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';

const require = createRequire(import.meta.url);
let playwright;
for (const location of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(location); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', arg('--label', 'contact-local'));
await fs.mkdir(output, { recursive: true });
const methods = { phone: { value: '13292625050', name: '电话号码' }, qq: { value: '1137670175', name: 'QQ号' } };
const results = [], runtimeProblems = [], screenshots = [];
const assert = (ok, detail) => { if (!ok) throw new Error(detail); };
let sentinelIndex = 0;

// Clipboard operations stay serial: engines can share a system clipboard.
// The native success path is never mocked. A unique sentinel prevents stale
// clipboard contents or a previous success toast from producing a false pass.
for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  } catch (error) { results.push({ engine, test: '浏览器启动', pass: false, details: error.message }); continue; }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, hasTouch: true });
  const page = await context.newPage();
  let originalClipboardText;
  function watch(observedPage, scope) {
    observedPage.on('pageerror', error => runtimeProblems.push({ engine, scope, type: 'pageerror', details: error.message }));
    observedPage.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, scope, type: 'console', details: message.text() }); });
    observedPage.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, scope, type: 'http', details: `${response.status()} ${new URL(response.url()).pathname}` }); });
    observedPage.on('requestfailed', request => { if (!/ABORTED|cancelled/i.test(request.failure()?.errorText || '')) runtimeProblems.push({ engine, scope, type: 'request', details: `${new URL(request.url()).pathname}: ${request.failure()?.errorText}` }); });
  }
  watch(page, 'native');
  async function check(test, run) {
    try { const details = await run(); results.push({ engine, test, pass: true, details: details ?? '' }); console.log(`PASS ${engine} ${test}`); }
    catch (error) { results.push({ engine, test, pass: false, details: String(error.message).slice(0, 1000) }); console.log(`FAIL ${engine} ${test}: ${error.message}`); }
  }
  async function loadHome(observedPage = page) {
    await observedPage.goto('about:blank');
    const response = await observedPage.goto(target.href, { waitUntil: 'networkidle' });
    assert(response && [200, 304].includes(response.status()), `首页响应 ${response?.status()}`);
  }
  async function showContact(observedPage = page) {
    await observedPage.locator('#contact').evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
    await observedPage.waitForTimeout(1000);
  }
  async function contactPosition(observedPage = page) {
    return observedPage.evaluate(() => {
      const title = document.querySelector('#contact h2').getBoundingClientRect();
      const header = document.querySelector('.site-header').getBoundingClientRect();
      return { scrollY, viewportHeight: innerHeight, title: title.toJSON(), header: header.toJSON(), headerPosition: getComputedStyle(document.querySelector('.site-header')).position };
    });
  }
  async function waitForContactArrival() {
    // A long native smooth scroll can outlast one second. Wait for visible,
    // stable geometry, including the section's reveal transform, instead.
    await page.evaluate(() => { window.__contactQaScroll = null; });
    try {
      await page.waitForFunction(() => {
        const title = document.querySelector('#contact h2').getBoundingClientRect();
        const now = performance.now(), previous = window.__contactQaScroll;
        const visible = title.top >= -1 && title.bottom <= innerHeight + 1;
        if (!previous || !visible || Math.abs(previous.scrollY - scrollY) > 0.25 || Math.abs(previous.titleTop - title.top) > 0.25) {
          window.__contactQaScroll = { scrollY, titleTop: title.top, since: now };
          return false;
        }
        return now - previous.since >= 250;
      }, null, { timeout: 8000 });
    } catch { throw new Error(`联系标题未稳定进入视口：${JSON.stringify(await contactPosition())}`); }
    const position = await contactPosition();
    assert(position.title.top >= -1 && position.title.bottom <= position.viewportHeight + 1, `联系标题不在视口内：${JSON.stringify(position)}`);
    const titleUncovered = await page.locator('#contact h2').evaluate(element => {
      const rect = element.getBoundingClientRect();
      const hit = document.elementFromPoint(rect.x + rect.width / 2, rect.y + Math.min(24, rect.height / 2));
      return hit === element || element.contains(hit);
    });
    assert(titleUncovered, `联系标题被覆盖：${JSON.stringify(position)}`);
    return position;
  }
  async function input(button, mode, observedPage = page) {
    await button.focus();
    await button.evaluate(element => {
      window.__contactQaFocus?.cleanup?.();
      const state = { atClick: null, toastFocused: false };
      const clicked = () => { state.atClick = document.activeElement; };
      const focused = event => { if (event.target.closest?.('.toast')) state.toastFocused = true; };
      element.addEventListener('click', clicked, { capture: true, once: true });
      document.addEventListener('focusin', focused, true);
      state.cleanup = () => { element.removeEventListener('click', clicked, true); document.removeEventListener('focusin', focused, true); };
      window.__contactQaFocus = state;
    });
    if (mode === 'Enter' || mode === 'Space') await observedPage.keyboard.press(mode);
    else {
      const box = await button.boundingBox(); assert(box, '复制按钮没有可见位置');
      const position = { x: box.x + box.width / 2, y: box.y + box.height / 2 };
      assert(await observedPage.evaluate(({ position, button }) => document.elementFromPoint(position.x, position.y)?.closest('[data-copy-contact]') === button, { position, button: await button.elementHandle() }), '复制按钮坐标被遮挡');
      if (mode === 'touch') await observedPage.touchscreen.tap(position.x, position.y);
      else await observedPage.mouse.click(position.x, position.y);
    }
  }
  async function focusResult(button, mode) {
    const state = await button.evaluate((element, mode) => {
      const observed = window.__contactQaFocus, toast = document.querySelector('.toast');
      const describe = node => node ? { tag: node.tagName, copyMethod: node.closest?.('[data-contact-method]')?.dataset.contactMethod || null } : null;
      const result = {
        atClick: describe(observed?.atClick), afterFeedback: describe(document.activeElement),
        retainedFromClick: !!observed?.atClick && observed.atClick === document.activeElement,
        keyboardButtonRetained: !['Enter', 'Space'].includes(mode) || document.activeElement === element,
        toastFocused: observed?.toastFocused || document.activeElement === toast || toast.contains(document.activeElement),
        toastPassiveStatus: toast.getAttribute('role') === 'status' && toast.getAttribute('aria-live') === 'polite' && !toast.hasAttribute('tabindex') && toast.tabIndex === -1,
      };
      observed?.cleanup?.();
      return result;
    }, mode);
    // Safari moves focus to BODY during native mouse/touch activation, before
    // click. Preserve that actual click-time focus; keyboard keeps the button.
    assert(state.retainedFromClick && state.keyboardButtonRetained && !state.toastFocused && state.toastPassiveStatus, `复制反馈焦点异常：${JSON.stringify(state)}`);
    return state;
  }
  async function seedClipboard(text) {
    // A temporary setup button gives WebKit the user activation required for a
    // real write. It is removed before screenshots and never enters the site.
    await page.evaluate(value => {
      window.__contactQaSeed = { complete: false, error: null };
      const button = document.createElement('button');
      button.dataset.qaClipboardSeed = '';
      button.textContent = '准备复制验证';
      button.style.cssText = 'position:fixed;left:8px;top:8px;z-index:2147483647;padding:12px 18px;background:#e9efda;color:#222';
      button.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(value); window.__contactQaSeed.complete = true; }
        catch (error) { window.__contactQaSeed.error = error.name; }
      });
      document.body.append(button);
    }, text);
    try {
      await page.locator('[data-qa-clipboard-seed]').click();
      await page.waitForFunction(() => window.__contactQaSeed.complete || window.__contactQaSeed.error, null, { timeout: 3000 });
      const error = await page.evaluate(() => window.__contactQaSeed.error);
      assert(!error, `原生剪贴板测试准备失败：${error}`);
      assert(await page.evaluate(async value => (await navigator.clipboard.readText()) === value, text), '原生剪贴板测试哨兵未写入');
    } finally { await page.locator('[data-qa-clipboard-seed]').evaluateAll(elements => elements.forEach(element => element.remove())); }
  }
  async function nativeCopy(id, mode) {
    const expected = methods[id];
    await seedClipboard(`contact-qa-${engine}-${++sentinelIndex}`);
    const button = page.locator(`[data-contact-method="${id}"] [data-copy-contact]`);
    const url = page.url(), tabs = context.pages().length;
    await input(button, mode);
    await page.waitForFunction(name => { const toast = document.querySelector('.toast'); return toast.classList.contains('show') && toast.textContent.includes(name) && toast.textContent.includes('已复制'); }, expected.name, { timeout: 3000 });
    assert(await page.evaluate(async value => (await navigator.clipboard.readText()) === value, expected.value), '原生剪贴板没有得到准确号码');
    assert(page.url() === url && context.pages().length === tabs, '复制导致页面跳转或新窗口');
    const focus = await focusResult(button, mode);
    return { method: id, input: mode, nativeClipboardMatches: true, feedback: await page.locator('.toast').textContent(), focus };
  }
  async function layout(width) {
    const data = await page.evaluate(() => {
      const items = [...document.querySelectorAll('[data-contact-method]')];
      const outside = [];
      for (const element of items.flatMap(item => [item, ...item.querySelectorAll('.contact-number, [data-copy-contact]')])) {
        const box = element.getBoundingClientRect();
        if (box.x < -1 || box.right > innerWidth + 1 || element.scrollWidth > element.clientWidth + 1) outside.push(element.className);
      }
      const header = [...document.querySelectorAll('.site-header .brand,.site-header .desktop-nav,.site-header .header-actions')].filter(element => getComputedStyle(element).display !== 'none').map(element => ({ class: element.className, box: element.getBoundingClientRect().toJSON() }));
      const overlap = header.some((a, i) => header.slice(i + 1).some(b => Math.min(a.box.right, b.box.right) - Math.max(a.box.x, b.box.x) > 1 && Math.min(a.box.bottom, b.box.bottom) - Math.max(a.box.y, b.box.y) > 1));
      return { width: innerWidth, root: document.documentElement.scrollWidth, body: document.body.scrollWidth, cards: items.length, outside, header, overlap, contactNav: document.querySelectorAll('.desktop-nav a[href="#contact"],#mobile-nav a[href="#contact"]').length };
    });
    assert(data.width === width && data.root <= width + 1 && data.body <= width + 1 && data.cards === 2 && !data.outside.length && !data.overlap && data.header.every(item => item.box.x >= -1 && item.box.right <= width + 1) && data.contactNav === 2, JSON.stringify(data));
    return data;
  }
  try {
    await loadHome();
    await check('安全上下文及真实剪贴板可核验', async () => {
      // WebKit supports clipboard-read but not the clipboard-write permission
      // name. Actual write permission comes from each real button activation.
      await context.grantPermissions(engine === 'chromium' ? ['clipboard-read', 'clipboard-write'] : ['clipboard-read'], { origin: target.origin });
      const capability = await page.evaluate(() => ({ secure: isSecureContext, write: typeof navigator.clipboard?.writeText === 'function', read: typeof navigator.clipboard?.readText === 'function' }));
      assert(capability.secure && capability.write && capability.read, JSON.stringify(capability));
      originalClipboardText = await page.evaluate(() => navigator.clipboard.readText());
      return capability;
    });
    await check('电话号码与QQ准确、电话地址正确且QQ不外跳', async () => {
      for (const [id, expected] of Object.entries(methods)) {
        const card = page.locator(`[data-contact-method="${id}"]`);
        assert(await card.count() === 1 && (await card.locator('.contact-number').innerText()).replace(/\s/g, '') === expected.value && await card.locator('[data-copy-contact]').getAttribute('data-copy-contact') === expected.value, `${id} 数字缺失或不准确`);
      }
      assert(await page.locator('[data-contact-method="phone"] .contact-number').getAttribute('href') === 'tel:13292625050', '电话href错误');
      assert(await page.locator('[data-contact-method="qq"] a[href]').count() === 0, 'QQ出现外跳链接');
      return { phone: methods.phone.value, qq: methods.qq.value, telReadOnly: true };
    });
    for (const width of [1440, 768, 390, 360]) {
      await page.setViewportSize({ width, height: width < 500 ? 844 : 1000 }); await showContact();
      await check(`${width}px 联系卡与导航无溢出或重叠`, () => layout(width));
      const modes = width === 1440 ? ['mouse', 'Enter'] : width === 768 ? ['Enter', 'mouse'] : width === 360 ? ['Space', 'touch'] : ['touch', 'touch'];
      for (const [index, id] of ['phone', 'qq'].entries()) await check(`${width}px ${id} ${modes[index]}真实复制`, () => nativeCopy(id, modes[index]));
      if ([1440, 390].includes(width)) { const destination = path.join(output, `${engine}-${width}-contact.png`); await page.locator('#contact').screenshot({ path: destination, animations: 'disabled' }); screenshots.push(destination); }
    }
    await page.setViewportSize({ width: 1024, height: 1000 });
    await check('1024px 新增联系导航无越界或重叠', () => layout(1024));
    for (const width of [1440, 390]) await check(`${width}px 导航原生到达联系区`, async () => {
      await page.setViewportSize({ width, height: width < 500 ? 844 : 1000 }); await loadHome();
      if (width < 500) { await page.locator('.menu-toggle').tap(); await page.locator('#mobile-nav a[href="#contact"]').tap(); }
      else { await page.locator('.desktop-nav a[href="#contact"]').focus(); await page.keyboard.press('Enter'); }
      await page.waitForURL(new URL('#contact', target).href, { waitUntil: 'networkidle' });
      const position = await waitForContactArrival();
      if (width < 500) assert(await page.locator('.menu-toggle').getAttribute('aria-expanded') === 'false', '联系导航后手机菜单未关闭');
      return position;
    });
    await page.setViewportSize({ width: 390, height: 844 });
    for (const mode of ['dark', 'paused', 'reduced']) await check(`390px ${mode} 联系卡可读且原生复制`, async () => {
      await loadHome();
      if (mode === 'dark') { await page.locator('.theme-toggle').click(); assert(await page.locator('html').getAttribute('data-theme') === 'dark', '深色模式未应用'); }
      if (mode === 'paused') { await page.locator('[data-motion-toggle]').focus(); await page.keyboard.press('Enter'); }
      if (mode === 'reduced') { await page.emulateMedia({ reducedMotion: 'reduce' }); await loadHome(); }
      await showContact(); await layout(390);
      assert(await page.locator('#contact').evaluate(element => getComputedStyle(element).opacity === '1'), '联系正文仍透明');
      const details = await nativeCopy(mode === 'paused' ? 'phone' : 'qq', mode === 'paused' ? 'Enter' : 'touch');
      const destination = path.join(output, `${engine}-390-${mode}-contact.png`); await page.locator('#contact').screenshot({ path: destination, animations: 'disabled' }); screenshots.push(destination);
      return details;
    });
    // This isolated context simulates the platform denying a write. It never
    // contributes to the native clipboard success result above.
    const deniedContext = await browser.newContext({ viewport: { width: 1440, height: 1000 }, hasTouch: true });
    await deniedContext.addInitScript(() => {
      window.__contactQaDenied = [];
      if (navigator.clipboard) Object.defineProperty(navigator.clipboard, 'writeText', { configurable: true, value: async value => { window.__contactQaDenied.push(value); throw new DOMException('QA simulated denial', 'NotAllowedError'); } });
    });
    const deniedPage = await deniedContext.newPage(); watch(deniedPage, 'simulated-denial');
    try {
      for (const width of [1440, 390]) {
        await deniedPage.setViewportSize({ width, height: width < 500 ? 844 : 1000 }); await loadHome(deniedPage); await showContact(deniedPage);
        for (const id of ['phone', 'qq']) await check(`${width}px ${id} 模拟剪贴板拒绝明确反馈`, async () => {
          const button = deniedPage.locator(`[data-contact-method="${id}"] [data-copy-contact]`), url = deniedPage.url();
          const attempts = await deniedPage.evaluate(() => window.__contactQaDenied.length);
          const mode = width < 500 ? 'touch' : 'Enter';
          await input(button, mode, deniedPage);
          await deniedPage.waitForFunction(() => { const toast = document.querySelector('.toast'); return toast.classList.contains('show') && toast.textContent === '未能复制，请长按或选中号码复制。'; }, null, { timeout: 3000 });
          assert(await deniedPage.evaluate(({ attempts, value }) => window.__contactQaDenied.length === attempts + 1 && window.__contactQaDenied.at(-1) === value, { attempts, value: methods[id].value }), '未实际尝试复制指定号码');
          const number = deniedPage.locator(`[data-contact-method="${id}"] .contact-number`);
          assert(await number.evaluate(element => getComputedStyle(element).userSelect !== 'none') && (await number.innerText()).replace(/\s/g, '') === methods[id].value, '拒绝后号码不可选中或不可读');
          assert(deniedPage.url() === url && deniedContext.pages().length === 1, '拒绝反馈导致跳转');
          const focus = await focusResult(button, mode);
          return { simulatedRefusal: true, manualCopyAvailable: true, feedback: await deniedPage.locator('.toast').textContent(), focus };
        });
      }
    } finally { await deniedContext.close(); }
    await check('联系方式相关运行时及网络错误为零', () => { const errors = runtimeProblems.filter(problem => problem.engine === engine); assert(!errors.length, JSON.stringify(errors.slice(0, 8))); });
  } finally {
    // Keep any original clipboard text private and restore it when possible.
    if (originalClipboardText !== undefined) {
      try { await seedClipboard(originalClipboardText); }
      catch (error) { console.log(`NOTE ${engine} 剪贴板文本恢复未完成：${error.name}`); }
    }
    await context.close(); await browser.close();
  }
}
const report = { timestamp: new Date().toISOString(), url: target.href, scope: 'Contact cards, native clipboard, explicitly simulated refusal, responsive navigation and appearance', clipboardSuccessMocked: false, refusalSimulated: true, telephoneActivated: false, qqExternalNavigation: false, results, runtimeProblems, screenshots, pass: results.every(result => result.pass) };
await fs.writeFile(path.join(output, 'contact-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(`结果：${results.filter(result => result.pass).length}/${results.length} 通过。`);
if (!report.pass) process.exitCode = 1;
