import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
import config from './qa-config.mjs';
import { inspectPublicCopy } from './public-copy.mjs';

const require = createRequire(import.meta.url);
let playwright;
for (const modulePath of [process.env.PLAYWRIGHT_MODULE, 'playwright', path.join(homedir(), '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright')].filter(Boolean)) {
  try { playwright = require(modulePath); break; } catch {}
}
if (!playwright) throw new Error('请按 tests/README.md 安装 Playwright');
const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const target = new URL(arg('--url', 'http://127.0.0.1:4322/'));
const output = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../.qa-output', arg('--label', 'revision-local'));
await fs.mkdir(output, { recursive: true });
const results = [];
const runtimeProblems = [];
const assert = (condition, message) => { if (!condition) throw new Error(message); };
async function loadImage(locator) {
  await locator.evaluate(image => image.complete ? Promise.resolve() : new Promise((resolve, reject) => {
    image.addEventListener('load', resolve, { once: true });
    image.addEventListener('error', () => reject(new Error('图片加载失败')), { once: true });
  }));
  assert(await locator.evaluate(image => image.naturalWidth > 0), '图片没有有效像素');
}
async function scrollThrough(page) {
  for (let y = 0; y < await page.evaluate(() => document.documentElement.scrollHeight); y += 650) {
    await page.evaluate(value => window.scrollTo({ top: value, behavior: 'instant' }), y);
    await page.waitForTimeout(65);
  }
  // Narrow galleries intentionally scroll horizontally. Visit every panel so
  // deferred offscreen images are tested through the same route as a visitor.
  for (const gallery of await page.locator('.gallery-grid').all()) {
    await gallery.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
    const size = await gallery.evaluate(element => ({ total: element.scrollWidth, viewport: element.clientWidth }));
    for (let left = 0; left < size.total; left += Math.max(1, size.viewport)) {
      await gallery.evaluate((element, value) => element.scrollTo({ left: value, behavior: 'instant' }), left);
      await page.waitForTimeout(100);
    }
  }
  await page.waitForTimeout(700);
}
async function noOverflow(page) {
  const data = await page.evaluate(() => ({ viewport: innerWidth, root: document.documentElement.scrollWidth, body: document.body.scrollWidth }));
  assert(data.root <= data.viewport + 1 && data.body <= data.viewport + 1, `屏幕=${data.viewport}, 页面=${data.root}, body=${data.body}`);
}
async function frozenDecorations(page) {
  await page.waitForTimeout(750);
  const running = await page.evaluate(() => document.getAnimations().filter(animation => {
    const timing = animation.effect?.getTiming();
    const element = animation.effect?.target;
    return element instanceof Element && element.closest('main') && animation.playState === 'running' && Number(timing?.duration) > 10;
  }).map(animation => `${animation.effect.target.tagName}.${animation.effect.target.className?.baseVal || animation.effect.target.className}`));
  assert(!running.length, `仍运行的页面动画：${running.slice(0, 7).join(', ')}`);
  const scene = page.locator('[data-playground]');
  await scene.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
  const box = await scene.boundingBox();
  assert(box, '互动场景不可见');
  await page.mouse.move(box.x + box.width * .2, box.y + box.height * .3);
  await page.waitForTimeout(100);
  const snapshot = () => page.locator('.character-stage, .character-card, .scene-sun, .scene-star, .orbit-lines').evaluateAll(elements => elements.map(element => getComputedStyle(element).transform));
  const before = await snapshot();
  await page.mouse.move(box.x + box.width * .8, box.y + box.height * .7);
  await page.waitForTimeout(350);
  assert(JSON.stringify(before) === JSON.stringify(await snapshot()), '暂停或减少动效时，装饰仍随鼠标或时间移动');
  const hidden = await page.locator('main [data-reveal], main [data-reveal-state]').evaluateAll(elements => elements.filter(element => getComputedStyle(element).opacity === '0').length);
  assert(hidden === 0, `${hidden} 段正文在停止动效后仍透明`);
}
async function frozenProjectSpot(page) {
  const cover = page.locator('.project-card .project-cover').first();
  await cover.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
  const box = await cover.boundingBox();
  assert(box, '项目卡片不可见');
  await page.mouse.move(box.x + box.width * .25, box.y + box.height * .35);
  await page.waitForTimeout(100);
  const snapshot = () => cover.evaluate(element => ({ x: element.style.getPropertyValue('--spot-x'), y: element.style.getPropertyValue('--spot-y') }));
  const before = await snapshot();
  await page.mouse.move(box.x + box.width * .75, box.y + box.height * .65);
  await page.waitForTimeout(200);
  assert(JSON.stringify(before) === JSON.stringify(await snapshot()), '项目光晕在停止动效后仍随鼠标移动');
}

for (const engine of ['chromium', 'webkit']) {
  let browser;
  try {
    browser = await playwright[engine].launch({ headless: true, ...(engine === 'chromium' && process.platform === 'darwin' ? { executablePath: process.env.QA_CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' } : {}) });
  } catch (error) { results.push({ engine, test: '浏览器启动', pass: false, details: error.message.split('\n')[0] }); continue; }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, hasTouch: true });
  const page = await context.newPage();
  page.on('pageerror', error => runtimeProblems.push({ engine, message: error.message }));
  page.on('console', message => { if (message.type() === 'error') runtimeProblems.push({ engine, message: message.text() }); });
  page.on('requestfailed', request => { if (!/ABORTED|cancelled/i.test(request.failure()?.errorText || '')) runtimeProblems.push({ engine, message: `${new URL(request.url()).pathname}: ${request.failure()?.errorText}` }); });
  page.on('response', response => { if (response.status() >= 400) runtimeProblems.push({ engine, message: `${response.status()} ${new URL(response.url()).pathname}` }); });
  async function check(test, run) {
    try { const details = await run(); results.push({ engine, test, pass: true, details: details || '' }); console.log(`PASS ${engine} ${test}`); }
    catch (error) { results.push({ engine, test, pass: false, details: String(error.message).slice(0, 600) }); console.log(`FAIL ${engine} ${test}: ${error.message}`); }
  }
  await page.goto(target.href, { waitUntil: 'networkidle' });
  await check('首页公开文案', () => inspectPublicCopy(page));
  for (const width of [360, 390, 430, 768, 1440]) {
    await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
    await check(`${width}px 首页方形小程序码清晰且无溢出`, async () => {
      const section = page.locator(config.homeQrSection);
      assert(await section.count() === 1, '首页没有独立体验区');
      await section.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await page.waitForTimeout(700);
      const image = page.locator(`${config.homeQrPanel} img`);
      await loadImage(image);
      const size = await image.evaluate(element => ({ width: element.getBoundingClientRect().width, height: element.getBoundingClientRect().height, naturalWidth: element.naturalWidth, naturalHeight: element.naturalHeight }));
      if ([360, 390, 1440].includes(width)) await page.screenshot({ path: path.join(output, `${engine}-${width}-home-qr.png`) });
      assert(size.naturalWidth >= 500 && size.naturalWidth === size.naturalHeight, '首页没有接入清晰的方形码');
      assert(Math.abs(size.width - size.height) < 2 && size.width >= 160, `二维码显示尺寸异常：${size.width} × ${size.height}`);
      await noOverflow(page);
    });
    if (![360, 390, 1440].includes(width)) continue;
    for (const [name, selector] of [['首屏体验按钮', config.homeQrHero], ['首页方形码', config.homeQrPanel]]) {
      await check(`${width}px ${name}可打开正确小程序码并返回焦点`, async () => {
        const trigger = page.locator(selector);
        assert(await trigger.count() === 1, `${name}缺失或重复`);
        await trigger.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
        await page.waitForTimeout(700);
        if (width < 500) await trigger.tap(); else { await trigger.focus(); await page.keyboard.press('Enter'); }
        const dialog = page.locator(config.lightboxDialog);
        await dialog.waitFor({ state: 'visible' });
        const image = dialog.locator('img');
        await loadImage(image);
        const data = await image.evaluate(element => ({ source: element.currentSrc, alt: element.alt, width: element.naturalWidth, height: element.naturalHeight, rect: element.getBoundingClientRect().toJSON() }));
        assert(data.width >= 500 && data.width === data.height && /灵岐智|小程序码/.test(data.alt), '弹窗打开了错误、非方形或低分辨率图片');
        assert(data.source === new URL(await trigger.getAttribute('data-lightbox'), target).href, '入口与弹窗图片来源不一致');
        const box = await dialog.boundingBox();
        assert(box && box.x >= -1 && box.x + box.width <= width + 1 && box.height <= (width < 768 ? 844 : 1000), '弹窗超出视口');
        await page.keyboard.press('Escape');
        assert(!await dialog.isVisible(), 'Escape 未关闭弹窗');
        assert(await trigger.evaluate(element => element === document.activeElement), '焦点未返回体验入口');
      });
    }
  }
  await check('首页保存小程序码链接返回图片', async () => {
    const link = page.locator(config.homeQrDownload);
    assert(await link.count() === 1 && await link.getAttribute('download') !== null, '首页下载入口缺失');
    const response = await context.request.get(new URL(await link.getAttribute('href'), target).href);
    assert(response.status() === 200 && /image/.test(response.headers()['content-type']), '首页保存链接未返回图片');
  });
  await check('创新大赛金银奖优先展示且筛选正确', async () => {
    await page.locator(`${config.awardFilters}[data-award-filter="all"]`).click();
    const rows = await page.locator(config.awardItems).evaluateAll(elements => elements.map(element => ({ text: element.innerText, level: element.dataset.level, certificate: Boolean(element.querySelector('[data-lightbox]')) })));
    assert(rows.length === 16, `精选荣誉数量=${rows.length}`);
    assert(rows.slice(0, 3).every(row => row.text.includes('中国国际大学生创新大赛') && row.level === 'provincial'), '创新大赛没有优先排列');
    assert(rows[0].text.includes('金奖') && rows.slice(1, 3).every(row => row.text.includes('银奖')), '金银奖排序或内容不正确');
    assert(rows.slice(0, 3).every(row => !row.certificate), '尚未提供证书的创新大赛奖项使用了证书入口');
    for (const [filter, expected] of [['national', 5], ['provincial', 10], ['special', 1]]) {
      await page.locator(`${config.awardFilters}[data-award-filter="${filter}"]`).click();
      const levels = await page.locator(config.awardItems).evaluateAll(elements => elements.filter(element => !element.hidden).map(element => element.dataset.level));
      assert(levels.length === expected && levels.every(level => level === filter), `${filter} 筛选错误：${levels.length}`);
    }
    await page.locator(`${config.awardFilters}[data-award-filter="all"]`).click();
  });
  await check('苗医数字馆已登记软著及真实证书可查看', async () => {
    const trigger = page.locator(config.researchCertificate);
    assert(await trigger.count() === 1, '已登记证书入口应为一个');
    const item = trigger.locator('xpath=..');
    const text = await item.innerText();
    const status = await item.locator(':scope > span').innerText();
    assert(/SQLAlchemy|苗医数字馆/.test(text) && /已登记|完成登记/.test(text), '没有清晰显示对应软件及已登记状态');
    assert(/登记证书|已登记/.test(status) && !/受理/.test(status), '已下证软件仍列为受理状态');
    assert(/另有\s*2\s*项软件著作权申请已(?:获)?受理/.test(text), '其他两项软著申请的真实受理状态不完整');
    await trigger.click();
    const dialog = page.locator(config.lightboxDialog);
    await dialog.waitFor({ state: 'visible' });
    const image = dialog.locator('img');
    await loadImage(image);
    assert(await image.evaluate(element => /software-miao-museum-2026-registered\.webp/.test(element.currentSrc) && element.naturalWidth >= 1000), '未显示经过核验的登记证书');
    await page.screenshot({ path: path.join(output, `${engine}-copyright-dialog.png`) });
    await page.keyboard.press('Escape');
    assert(!await dialog.isVisible() && await trigger.evaluate(element => element === document.activeElement), '软著证书关闭或焦点恢复失败');
  });
  for (const id of ['lingqizhi', 'jingcheng']) {
    const route = new URL(`projects/${id}/`, target);
    await page.goto(route.href, { waitUntil: 'networkidle' });
    await check(`${id} 公开文案`, () => inspectPublicCopy(page));
    await check(`${id} 项目故事、流程和阅读导航完整`, async () => {
      const sections = page.locator(config.projectStories);
      assert(await sections.count() >= 3, '项目故事内容不足');
      const stories = await sections.evaluateAll(elements => elements.map(element => ({ heading: element.querySelector('h2')?.textContent?.trim(), paragraphs: Array.from(element.querySelectorAll('p:not(.section-kicker)')).map(p => p.innerText.trim()) })));
      assert(stories.every(story => story.heading && story.paragraphs.length > 0 && story.paragraphs.join('').length >= 60), '故事缺少标题或实质说明');
      const steps = await page.locator(`${config.projectWorkflow} li`).evaluateAll(elements => elements.map(element => ({ title: element.querySelector('h3')?.textContent?.trim(), text: element.querySelector('p')?.textContent?.trim() })));
      assert(steps.length >= 3 && steps.every(step => step.title && step.text?.length >= 12) && new Set(steps.map(step => step.title)).size === steps.length, '流程缺少独立且可读的步骤说明');
      const broken = await page.locator(`${config.projectOutline} a[href]`).evaluateAll(elements => elements.filter(element => !document.getElementById(decodeURIComponent(new URL(element.href).hash.slice(1)))).map(element => element.getAttribute('href')));
      assert(await page.locator(`${config.projectOutline} a[href]`).count() >= 3 && !broken.length, `阅读导航缺失或目标为空：${broken.join(', ')}`);
      return `${stories.length} 段故事，${steps.length} 个流程步骤`;
    });
    for (const width of [360, 390, 1440]) {
      await page.setViewportSize({ width, height: width < 768 ? 844 : 1000 });
      await scrollThrough(page);
      await check(`${id} ${width}px 扩展内容无溢出且图片已加载`, async () => {
        await noOverflow(page);
        const broken = await page.locator('main img').evaluateAll(elements => elements.filter(image => !image.complete || image.naturalWidth === 0).map(image => new URL(image.src).pathname));
        assert(!broken.length, `缺失图片：${broken.join(', ')}`);
        if (width === 390 || width === 1440) {
          await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
          await page.waitForTimeout(250);
          await page.screenshot({ path: path.join(output, `${engine}-${width}-${id}-detail.png`), fullPage: true });
        }
      });
    }
  }
  await page.goto(target.href, { waitUntil: 'networkidle' });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await check('装饰动效与项目光晕在正常模式下响应', async () => {
    const running = await page.evaluate(() => document.getAnimations().filter(animation => animation.playState === 'running' && animation.effect?.getTiming().iterations === Infinity && animation.effect?.target instanceof Element && animation.effect.target.closest('main')).length);
    assert(running >= 3, `没有正常运行的持续装饰动画：${running}`);
    assert(await page.locator('main [data-reveal-state]').count() > 0, '没有启用滚动渐入');
    const cover = page.locator('.project-card .project-cover').first();
    await cover.evaluate(element => element.scrollIntoView({ block: 'center', behavior: 'instant' }));
    await page.waitForTimeout(700);
    const box = await cover.boundingBox();
    assert(box, '项目卡片不可见');
    await page.mouse.move(box.x + box.width * .2, box.y + box.height * .3);
    const before = await cover.evaluate(element => [element.style.getPropertyValue('--spot-x'), element.style.getPropertyValue('--spot-y')]);
    await page.mouse.move(box.x + box.width * .8, box.y + box.height * .7);
    const after = await cover.evaluate(element => [element.style.getPropertyValue('--spot-x'), element.style.getPropertyValue('--spot-y')]);
    assert(before.every(Boolean) && JSON.stringify(before) !== JSON.stringify(after), '正常模式下项目光晕没有响应鼠标');
  });
  await check('主动暂停冻结 CSS 和鼠标装饰、全部正文可见', async () => {
    await page.locator(config.pauseMotion).click();
    assert(await page.locator(config.pauseMotion).getAttribute('aria-pressed') === 'true', '暂停未设置状态');
    await frozenDecorations(page);
    await frozenProjectSpot(page);
    await scrollThrough(page);
    await noOverflow(page);
  });
  await check('减少动态效果冻结装饰并保留扩展内容', async () => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.evaluate(() => localStorage.removeItem('likun-motion'));
    await page.reload({ waitUntil: 'networkidle' });
    await frozenDecorations(page);
    await frozenProjectSpot(page);
    assert(await page.evaluate(() => getComputedStyle(document.documentElement).scrollBehavior !== 'smooth'), '减少动效仍使用平滑滚动');
    await scrollThrough(page);
    await noOverflow(page);
    await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
    await page.waitForTimeout(250);
    await page.screenshot({ path: path.join(output, `${engine}-1440-reduced-motion.png`), fullPage: true });
  });
  await check('本轮内容与互动无运行时或网络错误', async () => {
    const errors = runtimeProblems.filter(problem => problem.engine === engine);
    assert(!errors.length, errors.slice(0, 6).map(error => error.message).join(' | '));
  });
  await browser.close();
}
const report = { timestamp: new Date().toISOString(), url: target.href, results, runtimeProblems, pass: results.every(result => result.pass) };
await fs.writeFile(path.join(output, 'revision-results.json'), JSON.stringify(report, null, 2));
console.log(`结果：${results.filter(result => result.pass).length}/${results.length} 通过。`);
if (!report.pass) process.exitCode = 1;
