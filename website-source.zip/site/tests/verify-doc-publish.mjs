// Compare published bytes before and after a documentation-only release.
// This proves resource consistency; it does not replace browser testing.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const args = process.argv.slice(2);
const arg = (key, fallback) => args.includes(key) ? args[args.indexOf(key) + 1] : fallback;
const site = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const target = new URL(arg('--url', 'https://lik285154-web.github.io/'));
const baseline = path.resolve(site, arg('--baseline', '.qa-output/revision-public/published-digests.json'));
const capture = args.includes('--capture');
async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  return (await Promise.all(entries.map(entry => entry.isDirectory() ? walk(path.join(dir, entry.name)) : path.join(dir, entry.name)))).flat();
}
const previous = capture ? null : JSON.parse(await fs.readFile(baseline, 'utf8'));
if (previous && previous.url !== target.href) throw new Error('基线网址与当前网址不同');
const dist = path.resolve(site, arg('--dist', 'dist'));
const paths = capture ? (await walk(dist)).map(file => path.relative(dist, file).split(path.sep).join('/')).sort() : Object.keys(previous.files);
const files = {};
const issues = [];
for (let i = 0; i < paths.length; i += 6) {
  const responses = await Promise.allSettled(paths.slice(i, i + 6).map(async relative => {
    const response = await fetch(new URL(relative, target), { cache: 'no-store', signal: AbortSignal.timeout(20_000) });
    if (response.status !== 200) throw new Error(`${relative}: HTTP ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    return { relative, digest: createHash('sha256').update(bytes).digest('hex'), bytes: bytes.length };
  }));
  for (const response of responses) {
    if (response.status === 'rejected') { issues.push(response.reason.message); continue; }
    const { relative, digest, bytes } = response.value;
    files[relative] = { digest, bytes };
    if (previous && previous.files[relative].digest !== digest) issues.push(`${relative}: 公开字节与完整测试版本不同`);
  }
}
const report = { timestamp: new Date().toISOString(), url: target.href, mode: capture ? 'capture' : 'compare', files, issues, pass: issues.length === 0 && paths.length > 0 };
await fs.mkdir(path.dirname(baseline), { recursive: true });
const resultPath = capture ? baseline : path.resolve(site, arg('--output', '.qa-output/revision-doc-check/resource-results.json'));
await fs.mkdir(path.dirname(resultPath), { recursive: true });
await fs.writeFile(resultPath, JSON.stringify(report, null, 2));
console.log(`${report.pass ? 'PASS' : 'FAIL'} ${capture ? '公开资源基线' : '文档发布后公开资源一致性'}：${Object.keys(files).length}/${paths.length}，差异或错误 ${issues.length}`);
if (issues.length) console.log(issues.join('\n'));
if (!report.pass) process.exitCode = 1;
