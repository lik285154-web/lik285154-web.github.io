#!/usr/bin/env node
/** Check the actual deployment directory without printing sensitive content. */
import { lstat, readdir, readFile } from 'node:fs/promises';
import { basename, dirname, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const siteRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outputRoot = resolve(siteRoot, process.argv[2] || 'dist');
const failures = [];
let filesChecked = 0;

const privatePathParts = new Set([
  '.git', 'node_modules', '策划', '私有审核', '私有材料索引',
  '来源快照', '我的个人材料', '原始材料',
]);
const privateContent = [
  'file:///Users/', '私密配置.env',
  '策划/私有审核', '策划/私有材料索引', 'OPENAI_API_KEY',
];
const secretPatterns = [
  ['OpenAI API 密钥', /\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}\b/],
  ['GitHub token', /\bgh[pousr]_[A-Za-z0-9]{36,}\b/],
  ['GitHub fine-grained token', /\bgithub_pat_[A-Za-z0-9_]{40,}\b/],
  ['私钥', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/],
];

function reject(path, reason) {
  // Log filenames and categories only; never log matching text or credentials.
  let label = relative(outputRoot, path) || '.';
  for (const [, pattern] of secretPatterns) {
    label = label.replace(new RegExp(pattern.source, 'g'), '[隐藏]');
  }
  failures.push(`${label}: ${reason}`);
}

async function inspect(path) {
  const entry = await lstat(path);
  const name = basename(path);
  for (const [category, pattern] of secretPatterns) {
    if (pattern.test(name)) reject(path, `文件名发现疑似${category}`);
  }
  if (entry.isSymbolicLink()) {
    reject(path, '发布目录不得使用符号链接');
    return;
  }
  if (privatePathParts.has(name) || /^\.env(?:\.|$)/i.test(name) || /私密配置/.test(name) || /\.(?:env|key|pem)$/i.test(name)) {
    reject(path, '发现私有文件或目录');
    return;
  }
  if (entry.isDirectory()) {
    for (const child of await readdir(path)) await inspect(resolve(path, child));
    return;
  }
  if (!entry.isFile()) {
    reject(path, '发现非普通文件');
    return;
  }
  filesChecked += 1;
  const content = (await readFile(path)).toString('utf8');
  if (privateContent.some((value) => content.includes(value)) || /\/(?:Users|home)\/[^/\s]+\/(?:Desktop|Documents)\//.test(content)) {
    reject(path, '发现本机路径、私有材料引用或密钥环境变量');
  }
  for (const [category, pattern] of secretPatterns) {
    if (pattern.test(content)) reject(path, `发现疑似${category}`);
  }
}

try {
  if (outputRoot === siteRoot || !outputRoot.startsWith(`${siteRoot}${sep}`)) {
    throw new Error('检查目录必须位于网站目录内，且不能是网站源码根目录');
  }
  await inspect(outputRoot);
  const index = await lstat(resolve(outputRoot, 'index.html'));
  if (!index.isFile()) throw new Error('没有找到首页 index.html');
  if (filesChecked === 0) throw new Error('发布目录为空');
} catch (error) {
  console.error(`公开文件检查失败：${error.code === 'ENOENT' ? '请先运行 npm run build，生成 dist/index.html。' : error.message}`);
  process.exit(1);
}

if (failures.length > 0) {
  console.error('公开文件检查失败（不会显示敏感内容）：');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`公开文件检查通过：${filesChecked} 个文件，没有发现私有目录、本机路径或常见密钥。`);
console.log('此检查不能代替对图片、证书和个人信息的人工复核。');
