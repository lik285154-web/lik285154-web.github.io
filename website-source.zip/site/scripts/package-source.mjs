import fs from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

// Standard Python ZIP creation preserves relative paths and excludes local data.
const root = process.cwd();
const destination = path.resolve(root, '..', 'website-source.zip');
const python = process.env.PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
const code = `
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
r=Path(sys.argv[1]);out=Path(sys.argv[2])
excluded={'.git','node_modules','dist','.astro','.qa-output','output'}
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for p in sorted(r.rglob('*')):
  rel=p.relative_to(r)
  if not p.is_file() or p.is_symlink() or any(x in excluded for x in rel.parts):continue
  if p.name.startswith('.env') or p.name=='.DS_Store' or p.name.endswith('-public.png'):continue
  z.write(p,'site/'+rel.as_posix())
print('已打包可恢复源码：'+str(out))
print('大小：'+str(round(out.stat().st_size/1024/1024,2))+' MB')
if out.stat().st_size>=25*1024*1024:raise SystemExit('压缩包超过GitHub网页单文件限制，请检查素材体积。')
`;
try { execFileSync(python, ['-c', code, root, destination], { stdio: 'inherit' }); }
catch { console.error('源码打包失败：请安装 Python 3，并从 site 文件夹运行此命令。'); process.exit(1); }
const stat = await fs.stat(destination);
if (!stat.isFile()) process.exit(1);
