const root = document.documentElement;
const prefersReduced = matchMedia('(prefers-reduced-motion: reduce)');
let motionPaused = prefersReduced.matches;
let greetingAnimation: Animation | undefined;
try { motionPaused ||= localStorage.getItem('likun-motion') === 'paused'; } catch {}

function setMotion(paused: boolean) {
  motionPaused = paused;
  if (paused) { greetingAnimation?.cancel(); greetingAnimation = undefined; }
  root.dataset.motion = paused ? 'paused' : 'running';
  if (paused) document.querySelectorAll<HTMLElement>('[data-reveal-state]').forEach(element => { element.dataset.revealState = 'visible'; });
  document.querySelectorAll<HTMLButtonElement>('[data-motion-toggle]').forEach(button => {
    button.setAttribute('aria-pressed', String(paused));
    button.innerHTML = `${paused ? '开启动效' : '暂停动效'} <span>${paused ? '▷' : 'Ⅱ'}</span>`;
  });
}
setMotion(motionPaused);
document.querySelectorAll('[data-motion-toggle]').forEach(button => button.addEventListener('click', () => {
  setMotion(!motionPaused);
  try { localStorage.setItem('likun-motion', motionPaused ? 'paused' : 'running'); } catch {}
}));
prefersReduced.addEventListener('change', event => { if (event.matches) setMotion(true); });

const themeButton = document.querySelector<HTMLButtonElement>('.theme-toggle');
function updateThemeLabel() { themeButton?.setAttribute('aria-label', root.dataset.theme === 'dark' ? '切换浅色模式' : '切换深色模式'); }
updateThemeLabel();
themeButton?.addEventListener('click', () => {
  root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem('likun-theme', root.dataset.theme); } catch {}
  updateThemeLabel();
});

const menuToggle = document.querySelector<HTMLButtonElement>('.menu-toggle');
const mobileNav = document.querySelector<HTMLElement>('#mobile-nav');
function closeMenu() {
  menuToggle?.setAttribute('aria-expanded', 'false');
  menuToggle?.setAttribute('aria-label', '打开导航菜单');
  mobileNav?.classList.remove('open');
  if (mobileNav) mobileNav.inert = true;
}
menuToggle?.addEventListener('click', () => {
  const opening = menuToggle.getAttribute('aria-expanded') !== 'true';
  menuToggle.setAttribute('aria-expanded', String(opening));
  menuToggle.setAttribute('aria-label', opening ? '关闭导航菜单' : '打开导航菜单');
  mobileNav?.classList.toggle('open', opening);
  if (mobileNav) mobileNav.inert = !opening;
});
mobileNav?.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
document.addEventListener('click', event => {
  if (mobileNav?.classList.contains('open') && !mobileNav.contains(event.target as Node) && !menuToggle?.contains(event.target as Node)) closeMenu();
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && mobileNav?.classList.contains('open')) { closeMenu(); menuToggle?.focus(); }
});
matchMedia('(min-width: 621px)').addEventListener('change', event => { if (event.matches) closeMenu(); });

document.querySelectorAll<HTMLButtonElement>('[data-award-filter]').forEach(button => button.addEventListener('click', () => {
  const filter = button.dataset.awardFilter;
  document.querySelectorAll('[data-award-filter]').forEach(el => el.setAttribute('aria-pressed', String(el === button)));
  let count = 0;
  document.querySelectorAll<HTMLElement>('[data-award-item]').forEach(item => {
    item.hidden = filter !== 'all' && item.dataset.level !== filter;
    if (!item.hidden) count++;
  });
  const counter = document.querySelector('.filter-count');
  if (counter) counter.textContent = `共 ${count} 项`;
}));

const contactToast = document.querySelector<HTMLElement>('.toast');
let contactToastTimer: number | undefined;
let latestCopyRequest = 0;
function showContactFeedback(message: string) {
  if (!contactToast) return;
  contactToast.textContent = message;
  contactToast.classList.add('show');
  if (contactToastTimer) window.clearTimeout(contactToastTimer);
  contactToastTimer = window.setTimeout(() => contactToast.classList.remove('show'), 3500);
}
document.querySelectorAll<HTMLButtonElement>('[data-copy-contact]').forEach(button => button.addEventListener('click', async () => {
  const value = button.dataset.copyContact;
  if (!value) return;
  const request = ++latestCopyRequest;
  try {
    if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
    await navigator.clipboard.writeText(value);
    if (request === latestCopyRequest) showContactFeedback(`${button.dataset.copyName || '号码'}已复制`);
  } catch {
    if (request === latestCopyRequest) showContactFeedback('未能复制，请长按或选中号码复制。');
  }
}));

const dialog = document.querySelector<HTMLDialogElement>('#image-dialog');
const dialogImage = document.querySelector<HTMLImageElement>('#dialog-image');
let dialogTrigger: HTMLElement | null = null;
document.querySelectorAll<HTMLElement>('[data-lightbox]').forEach(trigger => trigger.addEventListener('click', () => {
  if (!dialog || !dialogImage) return;
  dialogTrigger = trigger;
  dialogImage.src = trigger.dataset.lightbox || '';
  dialogImage.alt = trigger.dataset.title || '图片';
  const title = document.querySelector('#image-dialog-title');
  const caption = document.querySelector('#dialog-caption');
  if (title) title.textContent = trigger.dataset.title || '查看图片';
  if (caption) caption.textContent = trigger.dataset.caption || '';
  dialog.showModal();
  document.body.style.overflow = 'hidden';
}));
function closeDialog() { dialog?.close(); }
document.querySelector('[data-close-dialog]')?.addEventListener('click', closeDialog);
dialog?.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const box = dialog.getBoundingClientRect();
  if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) closeDialog();
});
dialog?.addEventListener('close', () => {
  document.body.style.overflow = '';
  dialogTrigger?.focus({ preventScroll: true });
  dialogImage?.removeAttribute('src');
});
dialogImage?.addEventListener('error', () => {
  const caption = document.querySelector('#dialog-caption');
  if (caption) caption.textContent = '图片暂时无法加载，请关闭后重新打开。';
});

const scene = document.querySelector<HTMLElement>('[data-playground]');
scene?.addEventListener('pointermove', event => {
  if (motionPaused || prefersReduced.matches || event.pointerType !== 'mouse') return;
  const rect = scene.getBoundingClientRect();
  scene.style.setProperty('--tilt-x', `${-(event.clientY - rect.top - rect.height / 2) / 50}deg`);
  scene.style.setProperty('--tilt-y', `${(event.clientX - rect.left - rect.width / 2) / 40}deg`);
});
scene?.addEventListener('pointerleave', () => { scene.style.setProperty('--tilt-x', '0deg'); scene.style.setProperty('--tilt-y', '0deg'); });
const sprite = document.querySelector<HTMLButtonElement>('[data-sprite-greet]');
const spriteMessage = document.querySelector<HTMLElement>('[data-sprite-message]');
const spriteGreetings = ['你好呀，一起探索 AI 的新可能！', '保持好奇，把想法做成作品。', '学习和打球一样，总有下一步。'];
const spriteArtwork = sprite?.querySelector<HTMLElement>('[data-sprite-art]');
let greetingCount = 0;
sprite?.addEventListener('click', () => {
  if (spriteMessage) spriteMessage.textContent = spriteGreetings[greetingCount++ % spriteGreetings.length];
  // Each activation gives immediate feedback; animate only the artwork, never its hit area.
  greetingAnimation?.cancel();
  greetingAnimation = undefined;
  if (spriteArtwork && !motionPaused && !prefersReduced.matches) {
    greetingAnimation = spriteArtwork.animate([
      { transform: 'translateY(0) rotate(0) scale(1)' },
      { transform: 'translateY(-9px) rotate(-5deg) scale(1.025)', offset: .32 },
      { transform: 'translateY(-3px) rotate(4deg) scale(1.015)', offset: .65 },
      { transform: 'translateY(0) rotate(0) scale(1)' },
    ], { duration: 580, easing: 'ease-in-out' });
  }
});
const ball = document.querySelector<HTMLButtonElement>('[data-shot]');
let shotCount = 0;
let shooting = false;
ball?.addEventListener('click', () => {
  if (shooting) return;
  shotCount++;
  const caption = document.querySelector('.shot-caption');
  if (motionPaused || prefersReduced.matches) { if (caption) caption.textContent = '好球！每一次尝试，都有新的可能。'; return; }
  shooting = true;
  ball.classList.add('shooting');
  if (caption) caption.textContent = '投出一个新想法…';
  setTimeout(() => { ball.classList.remove('shooting'); shooting = false; if (caption) caption.textContent = ['好球！下一次，也全力以赴。', '命中！保持手感，继续向前。', '这一球，送给持续努力的你。'][shotCount % 3]; }, 1330);
});

const progress = document.querySelector<HTMLElement>('.reading-progress');
let ticking = false;
function updateProgress() {
  if (progress) progress.style.width = `${Math.min(100, (scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight)) * 100)}%`;
  ticking = false;
}
addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(updateProgress); ticking = true; } }, { passive: true });
updateProgress();
const sections = document.querySelectorAll<HTMLElement>('section[id]');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    document.querySelectorAll<HTMLElement>('[data-nav]').forEach(link => { link.classList.toggle('active', link.dataset.nav === entry.target.id); });
  }), { rootMargin: '-20% 0px -60% 0px', threshold: 0 });
  sections.forEach(section => observer.observe(section));
}

// Content is visible by default; entrance effects are progressive enhancement.
if ('IntersectionObserver' in window && !motionPaused && !prefersReduced.matches) {
  const revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    (entry.target as HTMLElement).dataset.revealState = 'visible';
    revealObserver.unobserve(entry.target);
  }), { rootMargin: '0px 0px -30px 0px', threshold: 0.06 });
  document.querySelectorAll<HTMLElement>('.section-heading, .mini-program-panel, .about-text, .about-notes, .ability-row, .learning-program, .certification-card, .project-card, .project-row, .timeline-item, .honor-highlight, .award-item, .research-items article, .note-article, .contact-section, .project-story, .workflow-list > li, .feature-list > div, .project-gallery, .qr-section').forEach((element, index) => {
    element.dataset.revealState = 'pending';
    element.style.setProperty('--reveal-delay', `${(index % 3) * 65}ms`);
    revealObserver.observe(element);
  });

  const countObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    countObserver.unobserve(entry.target);
    const element = entry.target as HTMLElement;
    const node = element.firstChild;
    const target = Number.parseInt(node?.textContent || '', 10);
    if (!node || node.nodeType !== Node.TEXT_NODE || !Number.isFinite(target) || motionPaused || prefersReduced.matches) return;
    const started = performance.now();
    function nextFrame(time: number) {
      const fraction = Math.min(1, (time - started) / 850);
      node!.textContent = String(motionPaused || prefersReduced.matches ? target : Math.round(target * (1 - Math.pow(1 - fraction, 3))));
      if (fraction < 1 && !motionPaused && !prefersReduced.matches) requestAnimationFrame(nextFrame);
    }
    requestAnimationFrame(nextFrame);
  }), { threshold: 0.5 });
  document.querySelectorAll<HTMLElement>('.award-total > strong, .award-overview > div > strong').forEach(element => countObserver.observe(element));
}

document.querySelectorAll<HTMLElement>('.project-card').forEach(card => {
  const cover = card.querySelector<HTMLElement>('.project-cover');
  card.addEventListener('pointermove', event => {
    if (!cover || motionPaused || prefersReduced.matches || event.pointerType !== 'mouse') return;
    const bounds = cover.getBoundingClientRect();
    cover.style.setProperty('--spot-x', `${Math.max(0, Math.min(100, (event.clientX - bounds.left) / bounds.width * 100))}%`);
    cover.style.setProperty('--spot-y', `${Math.max(0, Math.min(100, (event.clientY - bounds.top) / bounds.height * 100))}%`);
  });
  card.addEventListener('pointerleave', () => { cover?.style.removeProperty('--spot-x'); cover?.style.removeProperty('--spot-y'); });
});
