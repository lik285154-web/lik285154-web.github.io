/** Small progressive enhancements for the Junction-inspired hero. */
export function initJunction(shouldReduce: () => boolean) {
  const metrics = [...document.querySelectorAll<HTMLElement>('[data-metric-value]')]
    .map(element => ({ element, target: Number(element.dataset.metricValue), done: false, started: false, frame: 0 }))
    .filter(metric => metric.element.dataset.metricValue?.trim() && Number.isSafeInteger(metric.target) && metric.target >= 0);
  const scene = document.querySelector<HTMLElement>('[data-playground]');
  const portal = scene?.querySelector<HTMLElement>('.hero-portal');
  if (!metrics.length && !portal) return;

  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const fineMouse = matchMedia('(hover: hover) and (pointer: fine)');
  const limited = () => shouldReduce() || reduced.matches || document.hidden;
  let observer: IntersectionObserver | undefined;

  function finish(metric: typeof metrics[number]) {
    if (metric.frame) cancelAnimationFrame(metric.frame);
    metric.frame = 0;
    metric.done = true;
    metric.element.textContent = String(metric.target);
    observer?.unobserve(metric.element);
  }

  function finishAll() { metrics.forEach(finish); observer?.disconnect(); }

  function count(metric: typeof metrics[number]) {
    if (metric.started || metric.done) return;
    metric.started = true;
    observer?.unobserve(metric.element);
    if (limited() || metric.target === 0) { finish(metric); return; }
    const began = performance.now();
    metric.element.textContent = '0';
    const frame = (time: number) => {
      metric.frame = 0;
      if (metric.done) return;
      if (limited() || !metric.element.isConnected) { finish(metric); return; }
      const progress = Math.max(0, Math.min(1, (time - began) / 900));
      metric.element.textContent = String(Math.round(metric.target * (1 - (1 - progress) ** 3)));
      if (progress === 1) finish(metric);
      else metric.frame = requestAnimationFrame(frame);
    };
    metric.frame = requestAnimationFrame(frame);
  }

  // HTML starts with complete values; unsupported observers and reduced motion
  // keep that readable state, and completed counters never run backwards.
  if (limited() || !('IntersectionObserver' in window)) finishAll();
  else {
    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const metric = metrics.find(item => item.element === entry.target);
        if (metric) count(metric);
      });
    }, { threshold: .4 });
    metrics.forEach(metric => observer!.observe(metric.element));
  }

  let pointerFrame = 0;
  let pointerX = 0;
  let pointerY = 0;
  function resetPortal() {
    if (pointerFrame) cancelAnimationFrame(pointerFrame);
    pointerFrame = 0;
    portal?.style.removeProperty('--portal-x');
    portal?.style.removeProperty('--portal-y');
  }

  if (portal && scene) {
    scene.addEventListener('pointermove', event => {
      if (event.pointerType !== 'mouse' || !fineMouse.matches || limited()) return;
      pointerX = event.clientX;
      pointerY = event.clientY;
      if (pointerFrame) return;
      pointerFrame = requestAnimationFrame(() => {
        pointerFrame = 0;
        if (!fineMouse.matches || limited()) { resetPortal(); return; }
        const bounds = scene.getBoundingClientRect();
        if (!bounds.width || !bounds.height) return;
        const percent = (value: number) => `${Math.max(0, Math.min(100, value)).toFixed(2)}%`;
        portal.style.setProperty('--portal-x', percent((pointerX - bounds.left) / bounds.width * 100));
        portal.style.setProperty('--portal-y', percent((pointerY - bounds.top) / bounds.height * 100));
      });
    }, { passive: true });
    scene.addEventListener('pointerleave', resetPortal);
    scene.addEventListener('pointercancel', resetPortal);
  }

  function syncMotion() {
    if (!limited()) return;
    finishAll();
    resetPortal();
  }
  document.addEventListener('likun:motion-change', syncMotion);
  document.addEventListener('visibilitychange', syncMotion);
  reduced.addEventListener('change', syncMotion);
  fineMouse.addEventListener('change', () => { if (!fineMouse.matches) resetPortal(); });
}
