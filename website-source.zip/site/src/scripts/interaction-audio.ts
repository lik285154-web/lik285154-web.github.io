/** Synthesized basketball feedback. Call play methods from an audible, trusted click. */

export interface InteractionAudio {
  playShot(hitDelaySeconds: number, compact?: boolean): void;
  playPreview(): void;
  cancel(): void;
}

const MASTER_GAIN = .42;
const START_LEAD = .016;
const CANCEL_FADE = .009;
const CANCEL_STOP = .012;
const IDLE_SUSPEND_MS = 4000;

let sharedContext: AudioContext | undefined;
let idleSuspendTimer: ReturnType<typeof setTimeout> | undefined;
let pendingSuspend: Promise<void> | undefined;
const activity = new Set<symbol>();
const noiseBuffers = new WeakMap<BaseAudioContext, AudioBuffer>();

function clearIdleSuspend() {
  if (idleSuspendTimer !== undefined) clearTimeout(idleSuspendTimer);
  idleSuspendTimer = undefined;
}

function scheduleIdleSuspend() {
  if (activity.size) return;
  clearIdleSuspend();
  const context = sharedContext;
  if (!context) return;
  idleSuspendTimer = setTimeout(() => {
    idleSuspendTimer = undefined;
    if (activity.size || sharedContext !== context || context.state !== 'running') return;
    try {
      const operation = Promise.resolve(context.suspend()).then(() => {}, () => {});
      pendingSuspend = operation;
      void operation.then(() => { if (pendingSuspend === operation) pendingSuspend = undefined; });
    } catch { /* An idle suspension failure should not interrupt the page. */ }
  }, IDLE_SUSPEND_MS);
}

function releaseActivity(token: symbol) {
  if (activity.delete(token)) scheduleIdleSuspend();
}

function getSharedContext(): AudioContext {
  if (sharedContext && sharedContext.state !== 'closed') return sharedContext;
  if (typeof window === 'undefined') throw new Error('Web Audio is unavailable');
  const audioWindow = window as Window & {
    AudioContext?: typeof AudioContext;
    webkitAudioContext?: typeof AudioContext;
  };
  const Constructor = audioWindow.AudioContext || audioWindow.webkitAudioContext;
  if (!Constructor) throw new Error('Web Audio is unavailable');
  pendingSuspend = undefined;
  try { sharedContext = new Constructor({ latencyHint: 'interactive' }); }
  catch { sharedContext = new Constructor(); }
  return sharedContext;
}

function whiteNoise(context: BaseAudioContext): AudioBuffer {
  const cached = noiseBuffers.get(context);
  if (cached) return cached;
  const buffer = context.createBuffer(1, Math.ceil(context.sampleRate * .5), context.sampleRate);
  const samples = buffer.getChannelData(0);
  let seed = 0x65d2a319;
  for (let index = 0; index < samples.length; index++) {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    samples[index] = ((seed >>> 0) / 0xffffffff * 2 - 1) * .72;
  }
  noiseBuffers.set(context, buffer);
  return buffer;
}

function envelope(context: BaseAudioContext, at: number, duration: number, peak: number, attack: number): GainNode {
  const node = context.createGain();
  node.gain.value = 0;
  node.gain.setValueAtTime(0, at);
  node.gain.linearRampToValueAtTime(peak, at + attack);
  node.gain.exponentialRampToValueAtTime(.00001, at + duration - .008);
  node.gain.linearRampToValueAtTime(0, at + duration);
  return node;
}

/** The same synthesis runs against AudioContext and OfflineAudioContext. */
export function scheduleShotSounds(
  context: BaseAudioContext,
  output: AudioNode,
  startsAt: number,
  hitDelay: number,
  compact = false,
): AudioScheduledSourceNode[] {
  const start = Math.max(context.currentTime, Number.isFinite(startsAt) ? startsAt : context.currentTime);
  const delay = Math.max(0, Number.isFinite(hitDelay) ? hitDelay : 0);
  const hit = compact ? start + .014 : start + delay;
  const sources: AudioScheduledSourceNode[] = [];
  const cleanups: (() => void)[] = [];

  function connect(source: AudioScheduledSourceNode, processing: AudioNode[], gain: GainNode, at: number, duration: number) {
    const nodes = [source, ...processing, gain];
    const cleanup = () => { for (const node of nodes) { try { node.disconnect(); } catch {} } };
    cleanups.push(cleanup);
    sources.push(source);
    source.addEventListener('ended', cleanup, { once: true });
    for (let index = 0; index < nodes.length - 1; index++) nodes[index].connect(nodes[index + 1]);
    gain.connect(output);
    source.start(at);
    source.stop(at + duration + .008);
  }

  function tone(at: number, duration: number, peak: number, frequency: number, endingFrequency = frequency, attack = .005) {
    const source = context.createOscillator();
    source.type = 'sine';
    source.frequency.setValueAtTime(frequency, at);
    if (frequency !== endingFrequency) source.frequency.exponentialRampToValueAtTime(endingFrequency, at + duration * .75);
    connect(source, [], envelope(context, at, duration, peak, attack), at, duration);
  }

  function noise(at: number, duration: number, peak: number, type: BiquadFilterType, frequency: number, endingFrequency = frequency) {
    const source = context.createBufferSource();
    source.buffer = whiteNoise(context);
    const filter = context.createBiquadFilter();
    filter.type = type;
    filter.Q.value = .65;
    filter.frequency.setValueAtTime(frequency, at);
    if (frequency !== endingFrequency) filter.frequency.exponentialRampToValueAtTime(endingFrequency, at + duration * .85);
    const processing: AudioNode[] = [filter];
    if (type === 'highpass') {
      const softTop = context.createBiquadFilter();
      softTop.type = 'lowpass';
      softTop.frequency.value = 3800;
      softTop.Q.value = .65;
      processing.push(softTop);
    }
    connect(source, processing, envelope(context, at, duration, peak, Math.min(.016, duration * .18)), at, duration);
  }

  try {
    // A rounded pitch drop supplies the quiet floor contact, without a sharp transient.
    tone(start, compact ? .075 : .135, compact ? .032 : .082, 138, 66, .004);
    if (!compact) {
      noise(start + .002, .065, .012, 'lowpass', 750, 420);
      noise(start + .055, .18, .035, 'bandpass', 1150, 700);
    }
    noise(hit, compact ? .09 : .17, compact ? .025 : .052, 'highpass', 720, 1200);
    tone(hit + .015, compact ? .105 : .19, compact ? .025 : .038, 523.251, 523.251, .01);
    tone(hit + (compact ? .065 : .09), compact ? .125 : .22, compact ? .019 : .030, 659.255, 659.255, .012);
    return sources;
  } catch (error) {
    for (const source of sources) { try { source.stop(context.currentTime); } catch {} }
    for (const cleanup of cleanups) cleanup();
    throw error;
  }
}

interface AudioRequest {
  generation: number;
  token: symbol;
  context: AudioContext;
  createdAt: number;
  output?: GainNode;
  sources: AudioScheduledSourceNode[];
}

/** Creation is silent: no context or audio graph exists until a play method is called. */
export function createInteractionAudio(onUnavailable?: () => void): InteractionAudio {
  let generation = 0;
  let request: AudioRequest | undefined;
  let unavailableReported = false;
  const now = () => typeof performance === 'undefined' ? Date.now() : performance.now();
  const hidden = () => typeof document !== 'undefined' && document.hidden;

  function unavailable() {
    if (unavailableReported) return;
    unavailableReported = true;
    try { onUnavailable?.(); } catch { /* Feedback failures must not escape into the interaction. */ }
  }

  function cancel() {
    generation++;
    clearIdleSuspend();
    const previous = request;
    request = undefined;
    if (!previous) { scheduleIdleSuspend(); return; }
    const { context, output, sources } = previous;
    const at = context.currentTime;
    const running = context.state === 'running';
    if (output) {
      try {
        if (typeof output.gain.cancelAndHoldAtTime === 'function') output.gain.cancelAndHoldAtTime(at);
        else {
          const value = output.gain.value;
          output.gain.cancelScheduledValues(at);
          output.gain.setValueAtTime(value, at);
        }
        output.gain.linearRampToValueAtTime(0, at + (running ? CANCEL_FADE : 0));
      } catch { try { output.disconnect(); } catch {} }
      if (!running || !sources.length) { try { output.disconnect(); } catch {} }
    }
    // Stopping a future source before its start prevents delayed swishes after a mute.
    for (const source of sources) { try { source.stop(at + (running ? CANCEL_STOP : 0)); } catch {} }
    releaseActivity(previous.token);
  }

  function play(hitDelay: number, compact: boolean) {
    const activatedAt = now();
    cancel();
    if (hidden()) return;
    const delay = Math.max(0, Number.isFinite(hitDelay) ? hitDelay : 0);
    let context: AudioContext;
    try { context = getSharedContext(); } catch { unavailable(); return; }
    const current: AudioRequest = { generation, token: Symbol(), context, createdAt: activatedAt, sources: [] };
    request = current;
    activity.add(current.token);
    clearIdleSuspend();

    const valid = () => request === current && current.generation === generation && !hidden() && context.state !== 'closed';
    const abandon = () => {
      if (request === current) request = undefined;
      releaseActivity(current.token);
    };

    try {
      // This call remains synchronous with the native click, including the first unlock.
      const resumed = Promise.resolve(context.resume());
      const suspended = pendingSuspend;
      const ready = suspended ? Promise.all([suspended, resumed]) : resumed;
      void ready.then(async () => {
        if (!valid()) { abandon(); return; }
        // An already requested idle suspension can settle after the first resume call.
        if (context.state !== 'running') await context.resume();
        if (!valid()) { abandon(); return; }
        const elapsed = Math.max(0, (now() - current.createdAt) / 1000);
        if (elapsed > (compact ? .45 : Math.max(.6, delay + .55))) { abandon(); return; }
        if (context.state !== 'running') { abandon(); unavailable(); return; }
        const output = context.createGain();
        output.gain.value = MASTER_GAIN;
        current.output = output;
        output.connect(context.destination);
        // Keep the hit aligned with the visual shot even if initial resume took time.
        current.sources = scheduleShotSounds(context, output, context.currentTime + START_LEAD, Math.max(0, delay - elapsed - START_LEAD), compact);
        unavailableReported = false;
        let remaining = current.sources.length;
        for (const source of current.sources) source.addEventListener('ended', () => {
          if (--remaining) return;
          try { output.disconnect(); } catch {}
          if (request === current) request = undefined;
          releaseActivity(current.token);
        }, { once: true });
      }).catch(() => {
        if (request === current) { cancel(); unavailable(); }
        else releaseActivity(current.token);
      });
    } catch {
      if (request === current) { cancel(); unavailable(); }
      else releaseActivity(current.token);
    }
  }

  // The caller owns mute state; these guards also cover navigation and pending resumes.
  if (typeof document !== 'undefined') document.addEventListener('visibilitychange', () => { if (hidden()) cancel(); });
  if (typeof window !== 'undefined') window.addEventListener('pagehide', cancel);
  return {
    playShot: (hitDelaySeconds, compact = false) => play(hitDelaySeconds, compact),
    playPreview: () => play(0, true),
    cancel,
  };
}
