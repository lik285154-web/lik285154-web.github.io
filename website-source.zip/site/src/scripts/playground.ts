import { animate } from 'motion/mini';
import { createInteractionAudio } from './interaction-audio';

type Point = { x: number; y: number };
type Effect = ReturnType<typeof animate>;
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

export function initPlayground(shouldReduce: () => boolean) {
  const scene = document.querySelector<HTMLElement>('[data-playground]');
  const ball = scene?.querySelector<HTMLButtonElement>('[data-shot]');
  const artwork = ball?.querySelector<HTMLElement>('[data-ball-art]');
  const rim = scene?.querySelector<HTMLElement>('.hoop-rim');
  const net = scene?.querySelector<HTMLElement>('.hoop-net');
  const caption = scene?.querySelector<HTMLElement>('.shot-caption');
  const toggle = document.querySelector<HTMLButtonElement>('[data-sound-toggle]');
  if (!scene || !ball || !artwork || !rim) return;

  let soundEnabled = true;
  let soundAvailable = true;
  try { soundEnabled = localStorage.getItem('likun-sound') !== 'off'; } catch {}
  const effects = new Set<Effect>();
  const decorations = new Set<Element>();
  let shot: Effect | undefined;
  let shotBall: HTMLElement | undefined;
  let hitTimer: number | undefined;
  let fallbackTimer: number | undefined;
  let generation = 0;
  let attempts = 0;
  const audio = createInteractionAudio(() => {
    soundAvailable = false;
    soundEnabled = false;
    updateSound();
  });

  function updateSound() {
    if (!toggle) return;
    toggle.setAttribute('aria-pressed', String(soundEnabled));
    toggle.setAttribute('aria-label', soundAvailable ? `${soundEnabled ? '关闭' : '开启'}互动音效` : '暂时无法播放音效');
    toggle.dataset.sound = soundEnabled ? 'on' : 'off';
    const label = toggle.querySelector('[data-sound-label]');
    if (label) label.textContent = soundAvailable ? (soundEnabled ? '音效开启' : '音效关闭') : '音效暂不可用';
    toggle.disabled = !soundAvailable;
  }
  updateSound();
  toggle?.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    if (!soundEnabled) audio.cancel();
    else audio.playPreview();
    try { localStorage.setItem('likun-sound', soundEnabled ? 'on' : 'off'); } catch {}
    updateSound();
  });

  function finite(element: HTMLElement | SVGElement, frames: Parameters<typeof animate>[1], options: Parameters<typeof animate>[2]) {
    const effect = animate(element, frames, options);
    effects.add(effect);
    void effect.finished.then(() => effects.delete(effect), () => effects.delete(effect));
    return effect;
  }
  function removeDecorations() {
    effects.forEach(effect => effect.cancel());
    effects.clear();
    decorations.forEach(element => element.remove());
    decorations.clear();
  }
  function cancelShot() {
    generation++;
    window.clearTimeout(hitTimer);
    window.clearTimeout(fallbackTimer);
    shot?.cancel();
    shot = undefined;
    shotBall?.remove();
    shotBall = undefined;
    ball!.classList.remove('shooting');
    removeDecorations();
    audio.cancel();
  }
  function localCenter(element: Element): Point {
    const bounds = element.getBoundingClientRect();
    const stage = scene!.getBoundingClientRect();
    return { x: bounds.x + bounds.width / 2 - stage.x, y: bounds.y + bounds.height / 2 - stage.y };
  }
  function burst(center: Point, count: number) {
    if (shouldReduce() || document.hidden) return;
    for (let i = 0; i < count; i++) {
      const spark = document.createElement('span');
      spark.className = `playground-spark ${i % 3 === 0 ? 'spark-star' : ''}`;
      spark.setAttribute('aria-hidden', 'true');
      spark.style.setProperty('--spark-color', i % 2 ? 'var(--violet)' : 'var(--lime)');
      spark.textContent = i % 3 === 0 ? '✦' : '';
      const angle = i * Math.PI * 2 / count;
      const distance = 28 + i % 3 * 13;
      const end = { x: clamp(center.x + Math.cos(angle) * distance, 12, scene!.clientWidth - 12), y: clamp(center.y + Math.sin(angle) * distance, 12, scene!.clientHeight - 12) };
      spark.style.left = `${center.x}px`;
      spark.style.top = `${center.y}px`;
      scene!.append(spark);
      decorations.add(spark);
      const effect = finite(spark, {
        transform: ['translate(-50%, -50%) scale(.2)', `translate(calc(-50% + ${end.x - center.x}px), calc(-50% + ${end.y - center.y}px)) scale(1) rotate(${i * 29}deg)`],
        opacity: [0, .9, 0],
      }, { duration: .58 + i % 3 * .08, ease: [.16, 1, .3, 1] });
      void effect.finished.then(() => { spark.remove(); decorations.delete(spark); }, () => { spark.remove(); decorations.delete(spark); });
    }
  }
  function showTrail(start: Point, control: Point, target: Point) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.classList.add('shot-trail');
    svg.setAttribute('viewBox', `0 0 ${scene!.clientWidth} ${scene!.clientHeight}`);
    svg.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS(svg.namespaceURI, 'path');
    path.setAttribute('d', `M ${start.x} ${start.y} Q ${control.x} ${control.y} ${target.x} ${target.y}`);
    path.setAttribute('pathLength', '1');
    svg.append(path);
    scene!.append(svg);
    decorations.add(svg);
    finite(svg, { opacity: [0, .45, .12, 0] }, { duration: 1.4, times: [0, .28, .72, 1], ease: 'linear' });
  }

  ball.addEventListener('click', () => {
    cancelShot();
    attempts++;
    const compact = shouldReduce() || document.hidden || !('animate' in Element.prototype);
    if (compact) {
      if (caption) caption.textContent = '好球！每一次尝试，都有新的可能。';
      if (soundEnabled && !document.hidden) audio.playShot(.08, true);
      return;
    }
    const token = generation;
    const start = localCenter(artwork);
    const target = localCenter(rim);
    const size = ball.clientWidth;
    const aperture = Math.max(12, rim.getBoundingClientRect().width - 6);
    const fit = clamp(aperture * .84 / size, .35, .72);
    const startScale = Number.parseFloat(getComputedStyle(artwork).scale) || 1;
    const height = start.y - target.y;
    const control = { x: Math.max(size / 2 + 3, start.x - Math.min(85, scene.clientWidth * .18)), y: Math.max(size * fit / 2 + 12, target.y - clamp(height * .45, 85, 155)) };
    const duration = 1.45;
    const hitTime = .68;
    const frames: string[] = [];
    const times: number[] = [];
    const transform = (point: Point, scale: number, angle: number) => `translate(${point.x - size / 2}px, ${point.y - size / 2}px) rotate(${angle}deg) scale(${scale})`;
    for (let i = 0; i <= 40; i++) {
      const t = i / 40;
      const point = { x: (1 - t) ** 2 * start.x + 2 * (1 - t) * t * control.x + t ** 2 * target.x, y: (1 - t) ** 2 * start.y + 2 * (1 - t) * t * control.y + t ** 2 * target.y };
      frames.push(transform(point, startScale + (fit - startScale) * t, -19 + t * 410));
      times.push(t * hitTime);
    }
    frames.push(transform({ x: target.x, y: target.y + 39 }, fit, 440), transform(start, 1, 701), transform({ x: start.x, y: start.y - 13 }, 1, 701), transform(start, 1, 701));
    times.push(.77, .91, .955, 1);
    const flying = artwork.cloneNode(true) as HTMLElement;
    flying.removeAttribute('data-ball-art');
    flying.classList.add('shot-ball');
    flying.setAttribute('aria-hidden', 'true');
    flying.style.width = `${size}px`;
    flying.style.height = `${size}px`;
    flying.style.transform = frames[0];
    scene.append(flying);
    shotBall = flying;
    ball.classList.add('shooting');
    if (caption) caption.textContent = '投出一个新想法…';
    showTrail(start, control, target);
    if (soundEnabled) audio.playShot(duration * hitTime);
    shot = animate(flying, { transform: frames }, { duration, times, ease: 'linear' });
    hitTimer = window.setTimeout(() => {
      if (generation !== token) return;
      burst(target, 11);
      finite(rim, { transform: ['scale(1)', 'scale(1.13, .82)', 'scale(.98, 1.04)', 'scale(1)'] }, { duration: .42, ease: [.16, 1, .3, 1] });
      if (net) finite(net, { transform: ['scaleY(1)', 'scaleY(1.23) skewX(-6deg)', 'scaleY(.98) skewX(3deg)', 'scaleY(1)'] }, { duration: .55, ease: [.16, 1, .3, 1] });
      const sun = scene.querySelector<HTMLElement>('.scene-sun');
      if (sun) finite(sun, { opacity: [.6, .85, .6] }, { duration: .6 });
      if (caption) caption.textContent = ['好球！下一次，也全力以赴。', '命中！保持手感，继续向前。', '这一球，送给持续努力的你。'][attempts % 3];
    }, duration * hitTime * 1000);
    const complete = () => {
      if (generation !== token) return;
      shotBall?.remove();
      shotBall = undefined;
      ball.classList.remove('shooting');
      shot = undefined;
      window.clearTimeout(fallbackTimer);
      // Let the short net/particle response finish; keep no permanent scene nodes.
      window.setTimeout(() => { if (generation === token) removeDecorations(); }, 400);
    };
    void shot.finished.then(complete, complete);
    fallbackTimer = window.setTimeout(complete, 1900);
  });

  scene.querySelector('[data-sprite-greet]')?.addEventListener('click', () => {
    const sprite = scene.querySelector('[data-sprite-art]');
    if (!sprite || shouldReduce()) return;
    const bounds = sprite.getBoundingClientRect();
    const stage = scene.getBoundingClientRect();
    burst({ x: clamp(bounds.x + bounds.width * .76 - stage.x, 30, scene.clientWidth - 30), y: clamp(bounds.y + bounds.height * .3 - stage.y, 40, scene.clientHeight - 40) }, 7);
  });
  document.querySelectorAll<HTMLElement>('.hero-buttons .button, .hero-app-entry, .photo-link').forEach(button => button.addEventListener('click', () => {
    if (shouldReduce()) return;
    const icon = button.querySelector<HTMLElement | SVGElement>('.app-entry-icon, :scope > svg');
    if (icon) finite(icon, { transform: ['scale(1)', 'scale(.84)', 'scale(1.08)', 'scale(1)'] }, { duration: .33, ease: [.16, 1, .3, 1] });
  }));
  document.addEventListener('likun:motion-change', () => {
    if (!shouldReduce()) return;
    const hadShot = ball.classList.contains('shooting');
    cancelShot();
    if (hadShot && caption) caption.textContent = '动效已暂停，随时可以再投一球。';
  });
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) return;
    const hadShot = Boolean(shotBall);
    cancelShot();
    if (hadShot && caption) caption.textContent = '准备好了？再投一个好球。';
  });
  window.addEventListener('pagehide', cancelShot);
  window.addEventListener('resize', () => {
    if (!shotBall) return;
    cancelShot();
    if (caption) caption.textContent = '画面已调整，随时再投一球。';
  }, { passive: true });
}
