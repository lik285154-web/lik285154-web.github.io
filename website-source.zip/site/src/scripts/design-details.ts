// Decorative paths own their animation; existing text and interaction hit areas stay untouched.
export async function initDesignDetails(isPaused: () => boolean) {
  const trails = [...document.querySelectorAll<SVGSVGElement>('[data-section-trail]')];
  if (!trails.length || !('IntersectionObserver' in window) || isPaused()) return;

  let gsap: typeof import('gsap').gsap;
  try { ({ gsap } = await import('gsap')); }
  catch { return; } // Keep the complete SVG fallback if the optional animation chunk is unavailable.
  if (isPaused() || document.hidden) return;
  const media = gsap.matchMedia();

  media.add('(prefers-reduced-motion: no-preference)', context => {
    if (isPaused()) return;
    let active = true;
    const draw = (trail: SVGSVGElement) => { context.add(() => {
      const ink = trail.querySelector<SVGPathElement>('[data-trail-ink]');
      const tip = trail.querySelector<SVGGElement>('[data-trail-tip]');
      if (!active || document.hidden || !ink || !tip || isPaused()) return;
      const length = ink.getTotalLength();
      gsap.set(ink, { strokeDasharray: length, strokeDashoffset: length });
      gsap.set(tip, { opacity: 0, scale: .6, rotation: -25, transformOrigin: '50% 50%' });
      const timeline = gsap.timeline({
        defaults: { ease: 'power2.out' },
        onComplete: () => {
          trail.dataset.trailState = 'complete';
          gsap.set([ink, tip], { clearProps: 'all' });
        },
      });
      timeline.to(ink, { strokeDashoffset: 0, duration: .85 }, 0)
        .to(tip, { opacity: 1, scale: 1, rotation: 0, duration: .32 }, .58);
      trail.dataset.trailState = 'drawing';
    }); };
    const observer = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        observer.unobserve(entry.target);
        if (active && !document.hidden && !isPaused()) draw(entry.target as SVGSVGElement);
      }
    }, { threshold: .5, rootMargin: '0px 0px -28px 0px' });
    trails.forEach(trail => observer.observe(trail));
    return () => {
      active = false;
      observer.disconnect();
      trails.forEach(trail => { trail.dataset.trailState = 'complete'; });
    };
  });

  function stop() { media.revert(); }
  function onMotionChange() { if (isPaused()) stop(); }
  function onVisibilityChange() { if (document.hidden) stop(); }
  document.addEventListener('likun:motion-change', onMotionChange);
  document.addEventListener('visibilitychange', onVisibilityChange);
  window.addEventListener('pagehide', () => {
    stop();
    document.removeEventListener('likun:motion-change', onMotionChange);
    document.removeEventListener('visibilitychange', onVisibilityChange);
  }, { once: true });
}
