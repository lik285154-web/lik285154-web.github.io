export function href(path = '') {
  return `${import.meta.env.BASE_URL.replace(/\/$/, '')}/${path.replace(/^\//, '')}`;
}

export const shortAward = (name: string) => name
  .replace('第二十八届', '第28届')
  .replace('第十九届', '第19届')
  .replace('第十五届', '第15届');
